#ifndef CARTE_H
#define CARTE_H


#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>

class carte
{
public:
    carte();
    carte(int,QString,QString,QString);
    int get_cin();
    QString get_type() ;
    QString get_email() ;
    QString get_solde() ;
    bool ajouter();
    bool modifier();
    QSqlQueryModel * afficher();
    bool supprimer(int);
    QSqlQueryModel * tri() ;
    bool rechercher(int) ;
private:
    int cin;
    QString type,email,solde;
};
class carteh
{
public:
       carteh() ;
       carteh(int,QString,QString) ;
       int get_cin();
       QString get_datee();
       QString get_fn();
       QSqlQueryModel * afficherhis() ;
       bool ajoutehis();
       bool modifierhis() ;
private:
    int cin;
    QString datee,fn ;
};

#endif // CARTE_H
