/****************************************************************************
** Meta object code from reading C++ file 'VoiceTranslator.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../VoiceAssistant-master/VoiceTranslator.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'VoiceTranslator.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_VoiceTranslator_t {
    QByteArrayData data[13];
    char stringdata0[139];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_VoiceTranslator_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_VoiceTranslator_t qt_meta_stringdata_VoiceTranslator = {
    {
QT_MOC_LITERAL(0, 0, 15), // "VoiceTranslator"
QT_MOC_LITERAL(1, 16, 21), // "recordDurationChanged"
QT_MOC_LITERAL(2, 38, 0), // ""
QT_MOC_LITERAL(3, 39, 8), // "duration"
QT_MOC_LITERAL(4, 48, 14), // "runningChanged"
QT_MOC_LITERAL(5, 63, 7), // "running"
QT_MOC_LITERAL(6, 71, 14), // "commandChanged"
QT_MOC_LITERAL(7, 86, 4), // "text"
QT_MOC_LITERAL(8, 91, 12), // "errorChanged"
QT_MOC_LITERAL(9, 104, 5), // "start"
QT_MOC_LITERAL(10, 110, 14), // "recordDuration"
QT_MOC_LITERAL(11, 125, 7), // "command"
QT_MOC_LITERAL(12, 133, 5) // "error"

    },
    "VoiceTranslator\0recordDurationChanged\0"
    "\0duration\0runningChanged\0running\0"
    "commandChanged\0text\0errorChanged\0start\0"
    "recordDuration\0command\0error"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_VoiceTranslator[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       4,   52, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   39,    2, 0x06 /* Public */,
       4,    1,   42,    2, 0x06 /* Public */,
       6,    1,   45,    2, 0x06 /* Public */,
       8,    1,   48,    2, 0x06 /* Public */,

 // methods: name, argc, parameters, tag, flags
       9,    0,   51,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::LongLong,    3,
    QMetaType::Void, QMetaType::Bool,    5,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void, QMetaType::QString,    7,

 // methods: parameters
    QMetaType::Void,

 // properties: name, type, flags
      10, QMetaType::Int, 0x00495103,
      11, QMetaType::QString, 0x00495001,
      12, QMetaType::QString, 0x00495001,
       5, QMetaType::Bool, 0x00495001,

 // properties: notify_signal_id
       0,
       2,
       3,
       1,

       0        // eod
};

void VoiceTranslator::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<VoiceTranslator *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->recordDurationChanged((*reinterpret_cast< qint64(*)>(_a[1]))); break;
        case 1: _t->runningChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->commandChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->errorChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 4: _t->start(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (VoiceTranslator::*)(qint64 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&VoiceTranslator::recordDurationChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (VoiceTranslator::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&VoiceTranslator::runningChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (VoiceTranslator::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&VoiceTranslator::commandChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (VoiceTranslator::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&VoiceTranslator::errorChanged)) {
                *result = 3;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<VoiceTranslator *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< int*>(_v) = _t->getRecordDuration(); break;
        case 1: *reinterpret_cast< QString*>(_v) = _t->getCommand(); break;
        case 2: *reinterpret_cast< QString*>(_v) = _t->getError(); break;
        case 3: *reinterpret_cast< bool*>(_v) = _t->getRunning(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<VoiceTranslator *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setRecordDuration(*reinterpret_cast< int*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject VoiceTranslator::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_VoiceTranslator.data,
    qt_meta_data_VoiceTranslator,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *VoiceTranslator::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *VoiceTranslator::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_VoiceTranslator.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int VoiceTranslator::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 5)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 5;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 4;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void VoiceTranslator::recordDurationChanged(qint64 _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void VoiceTranslator::runningChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void VoiceTranslator::commandChanged(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void VoiceTranslator::errorChanged(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
