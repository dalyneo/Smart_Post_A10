/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDockWidget>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionOpen;
    QAction *action_Quit;
    QAction *actionTalk;
    QAction *actionPause;
    QAction *actionMove_to_speech_line;
    QAction *actionSkip_to_10_line;
    QAction *actionVolume_Up;
    QAction *actionVolume_Down;
    QAction *actionAbout;
    QAction *actionStart_at_last_speech;
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout;
    QPlainTextEdit *txtEditor;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QSpinBox *boxSpeechSpeed;
    QLabel *label;
    QSlider *volumeSlider;
    QSpinBox *boxVolume;
    QPushButton *btnTalk;
    QPushButton *btnPause;
    QPushButton *btnStop;
    QHBoxLayout *horizontalLayout_2;
    QMenuBar *menuBar;
    QMenu *menu_File;
    QMenu *menuSpeech;
    QMenu *menu_Help;
    QStatusBar *statusBar;
    QDockWidget *dockWidget;
    QWidget *dockWidgetContents;
    QFormLayout *formLayout;
    QSplitter *splitter;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_4;
    QSpinBox *boxJumpLine;
    QPushButton *btnJumpToLine;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout_2;
    QLineEdit *txtSearchText;
    QPushButton *btnSearchText;
    QCheckBox *chkAllowScroll;
    QLabel *lblLine;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(752, 368);
        MainWindow->setDocumentMode(true);
        MainWindow->setTabShape(QTabWidget::Rounded);
        actionOpen = new QAction(MainWindow);
        actionOpen->setObjectName(QString::fromUtf8("actionOpen"));
        action_Quit = new QAction(MainWindow);
        action_Quit->setObjectName(QString::fromUtf8("action_Quit"));
        action_Quit->setCheckable(false);
        action_Quit->setEnabled(true);
        actionTalk = new QAction(MainWindow);
        actionTalk->setObjectName(QString::fromUtf8("actionTalk"));
        actionPause = new QAction(MainWindow);
        actionPause->setObjectName(QString::fromUtf8("actionPause"));
        actionPause->setCheckable(true);
        actionMove_to_speech_line = new QAction(MainWindow);
        actionMove_to_speech_line->setObjectName(QString::fromUtf8("actionMove_to_speech_line"));
        actionSkip_to_10_line = new QAction(MainWindow);
        actionSkip_to_10_line->setObjectName(QString::fromUtf8("actionSkip_to_10_line"));
        actionVolume_Up = new QAction(MainWindow);
        actionVolume_Up->setObjectName(QString::fromUtf8("actionVolume_Up"));
        actionVolume_Down = new QAction(MainWindow);
        actionVolume_Down->setObjectName(QString::fromUtf8("actionVolume_Down"));
        actionAbout = new QAction(MainWindow);
        actionAbout->setObjectName(QString::fromUtf8("actionAbout"));
        actionStart_at_last_speech = new QAction(MainWindow);
        actionStart_at_last_speech->setObjectName(QString::fromUtf8("actionStart_at_last_speech"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        verticalLayout = new QVBoxLayout(centralWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        txtEditor = new QPlainTextEdit(centralWidget);
        txtEditor->setObjectName(QString::fromUtf8("txtEditor"));

        verticalLayout->addWidget(txtEditor);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);

        boxSpeechSpeed = new QSpinBox(centralWidget);
        boxSpeechSpeed->setObjectName(QString::fromUtf8("boxSpeechSpeed"));
        boxSpeechSpeed->setMinimum(1);
        boxSpeechSpeed->setMaximum(10);

        horizontalLayout->addWidget(boxSpeechSpeed);

        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        volumeSlider = new QSlider(centralWidget);
        volumeSlider->setObjectName(QString::fromUtf8("volumeSlider"));
        volumeSlider->setMaximum(100);
        volumeSlider->setSingleStep(10);
        volumeSlider->setPageStep(10);
        volumeSlider->setValue(50);
        volumeSlider->setOrientation(Qt::Horizontal);
        volumeSlider->setTickPosition(QSlider::TicksAbove);
        volumeSlider->setTickInterval(10);

        horizontalLayout->addWidget(volumeSlider);

        boxVolume = new QSpinBox(centralWidget);
        boxVolume->setObjectName(QString::fromUtf8("boxVolume"));
        boxVolume->setMaximum(100);

        horizontalLayout->addWidget(boxVolume);

        btnTalk = new QPushButton(centralWidget);
        btnTalk->setObjectName(QString::fromUtf8("btnTalk"));

        horizontalLayout->addWidget(btnTalk);

        btnPause = new QPushButton(centralWidget);
        btnPause->setObjectName(QString::fromUtf8("btnPause"));

        horizontalLayout->addWidget(btnPause);

        btnStop = new QPushButton(centralWidget);
        btnStop->setObjectName(QString::fromUtf8("btnStop"));

        horizontalLayout->addWidget(btnStop);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));

        verticalLayout->addLayout(horizontalLayout_2);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 752, 26));
        menu_File = new QMenu(menuBar);
        menu_File->setObjectName(QString::fromUtf8("menu_File"));
        menuSpeech = new QMenu(menuBar);
        menuSpeech->setObjectName(QString::fromUtf8("menuSpeech"));
        menu_Help = new QMenu(menuBar);
        menu_Help->setObjectName(QString::fromUtf8("menu_Help"));
        MainWindow->setMenuBar(menuBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);
        dockWidget = new QDockWidget(MainWindow);
        dockWidget->setObjectName(QString::fromUtf8("dockWidget"));
        dockWidget->setAcceptDrops(false);
        dockWidget->setAllowedAreas(Qt::LeftDockWidgetArea|Qt::RightDockWidgetArea);
        dockWidgetContents = new QWidget();
        dockWidgetContents->setObjectName(QString::fromUtf8("dockWidgetContents"));
        formLayout = new QFormLayout(dockWidgetContents);
        formLayout->setSpacing(6);
        formLayout->setContentsMargins(11, 11, 11, 11);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        splitter = new QSplitter(dockWidgetContents);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(splitter->sizePolicy().hasHeightForWidth());
        splitter->setSizePolicy(sizePolicy);
        splitter->setLineWidth(4);
        splitter->setOrientation(Qt::Vertical);
        splitter->setChildrenCollapsible(true);
        layoutWidget = new QWidget(splitter);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        horizontalLayout_4 = new QHBoxLayout(layoutWidget);
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        boxJumpLine = new QSpinBox(layoutWidget);
        boxJumpLine->setObjectName(QString::fromUtf8("boxJumpLine"));
        boxJumpLine->setMaximum(60000);
        boxJumpLine->setValue(0);

        horizontalLayout_4->addWidget(boxJumpLine);

        btnJumpToLine = new QPushButton(layoutWidget);
        btnJumpToLine->setObjectName(QString::fromUtf8("btnJumpToLine"));

        horizontalLayout_4->addWidget(btnJumpToLine);

        splitter->addWidget(layoutWidget);
        layoutWidget1 = new QWidget(splitter);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        verticalLayout_2 = new QVBoxLayout(layoutWidget1);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        txtSearchText = new QLineEdit(layoutWidget1);
        txtSearchText->setObjectName(QString::fromUtf8("txtSearchText"));
        txtSearchText->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        verticalLayout_2->addWidget(txtSearchText);

        btnSearchText = new QPushButton(layoutWidget1);
        btnSearchText->setObjectName(QString::fromUtf8("btnSearchText"));

        verticalLayout_2->addWidget(btnSearchText);

        chkAllowScroll = new QCheckBox(layoutWidget1);
        chkAllowScroll->setObjectName(QString::fromUtf8("chkAllowScroll"));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(chkAllowScroll->sizePolicy().hasHeightForWidth());
        chkAllowScroll->setSizePolicy(sizePolicy1);
        chkAllowScroll->setAcceptDrops(false);

        verticalLayout_2->addWidget(chkAllowScroll);

        splitter->addWidget(layoutWidget1);

        formLayout->setWidget(1, QFormLayout::LabelRole, splitter);

        lblLine = new QLabel(dockWidgetContents);
        lblLine->setObjectName(QString::fromUtf8("lblLine"));
        lblLine->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        formLayout->setWidget(0, QFormLayout::LabelRole, lblLine);

        dockWidget->setWidget(dockWidgetContents);
        MainWindow->addDockWidget(static_cast<Qt::DockWidgetArea>(2), dockWidget);

        menuBar->addAction(menu_File->menuAction());
        menuBar->addAction(menuSpeech->menuAction());
        menuBar->addAction(menu_Help->menuAction());
        menu_File->addAction(actionOpen);
        menu_File->addSeparator();
        menu_File->addAction(action_Quit);
        menuSpeech->addAction(actionTalk);
        menuSpeech->addAction(actionStart_at_last_speech);
        menuSpeech->addAction(actionPause);
        menuSpeech->addSeparator();
        menuSpeech->addAction(actionMove_to_speech_line);
        menuSpeech->addAction(actionSkip_to_10_line);
        menuSpeech->addSeparator();
        menuSpeech->addAction(actionVolume_Up);
        menuSpeech->addAction(actionVolume_Down);
        menu_Help->addAction(actionAbout);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "SimpleTextSpeech", nullptr));
        actionOpen->setText(QApplication::translate("MainWindow", "Open", nullptr));
#ifndef QT_NO_SHORTCUT
        actionOpen->setShortcut(QApplication::translate("MainWindow", "Ctrl+O", nullptr));
#endif // QT_NO_SHORTCUT
        action_Quit->setText(QApplication::translate("MainWindow", "&Quit", nullptr));
#ifndef QT_NO_SHORTCUT
        action_Quit->setShortcut(QApplication::translate("MainWindow", "Ctrl+Q", nullptr));
#endif // QT_NO_SHORTCUT
        actionTalk->setText(QApplication::translate("MainWindow", "Talk", nullptr));
#ifndef QT_NO_SHORTCUT
        actionTalk->setShortcut(QApplication::translate("MainWindow", "Ctrl+T", nullptr));
#endif // QT_NO_SHORTCUT
        actionPause->setText(QApplication::translate("MainWindow", "Pause", nullptr));
#ifndef QT_NO_SHORTCUT
        actionPause->setShortcut(QApplication::translate("MainWindow", "Ctrl+P", nullptr));
#endif // QT_NO_SHORTCUT
        actionMove_to_speech_line->setText(QApplication::translate("MainWindow", "Move to speech line", nullptr));
#ifndef QT_NO_SHORTCUT
        actionMove_to_speech_line->setShortcut(QApplication::translate("MainWindow", "Ctrl+G", nullptr));
#endif // QT_NO_SHORTCUT
        actionSkip_to_10_line->setText(QApplication::translate("MainWindow", "Skip to 10 line", nullptr));
#ifndef QT_NO_SHORTCUT
        actionSkip_to_10_line->setShortcut(QApplication::translate("MainWindow", "Ctrl+Shift+J", nullptr));
#endif // QT_NO_SHORTCUT
        actionVolume_Up->setText(QApplication::translate("MainWindow", "Volume Up", nullptr));
#ifndef QT_NO_SHORTCUT
        actionVolume_Up->setShortcut(QApplication::translate("MainWindow", "Ctrl+]", nullptr));
#endif // QT_NO_SHORTCUT
        actionVolume_Down->setText(QApplication::translate("MainWindow", "Volume Down", nullptr));
#ifndef QT_NO_SHORTCUT
        actionVolume_Down->setShortcut(QApplication::translate("MainWindow", "Ctrl+[", nullptr));
#endif // QT_NO_SHORTCUT
        actionAbout->setText(QApplication::translate("MainWindow", "About", nullptr));
        actionStart_at_last_speech->setText(QApplication::translate("MainWindow", "Start at last speech", nullptr));
#ifndef QT_NO_SHORTCUT
        actionStart_at_last_speech->setShortcut(QApplication::translate("MainWindow", "Ctrl+R", nullptr));
#endif // QT_NO_SHORTCUT
        label_2->setText(QApplication::translate("MainWindow", "Speed : ", nullptr));
        label->setText(QApplication::translate("MainWindow", "Volume :", nullptr));
        btnTalk->setText(QApplication::translate("MainWindow", "Talk", nullptr));
#ifndef QT_NO_SHORTCUT
        btnTalk->setShortcut(QString());
#endif // QT_NO_SHORTCUT
        btnPause->setText(QApplication::translate("MainWindow", "Pause", nullptr));
        btnStop->setText(QApplication::translate("MainWindow", "Stop", nullptr));
        menu_File->setTitle(QApplication::translate("MainWindow", "&File", nullptr));
        menuSpeech->setTitle(QApplication::translate("MainWindow", "&Speech", nullptr));
        menu_Help->setTitle(QApplication::translate("MainWindow", "&Help", nullptr));
        btnJumpToLine->setText(QApplication::translate("MainWindow", "Jump", nullptr));
        btnSearchText->setText(QApplication::translate("MainWindow", "Search", nullptr));
        chkAllowScroll->setText(QApplication::translate("MainWindow", "Allow Scroll", nullptr));
        lblLine->setText(QApplication::translate("MainWindow", " Line : 0", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
