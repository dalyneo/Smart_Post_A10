/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../SimpleTextSpeech-develop/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[30];
    char stringdata0[733];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 18), // "on_btnTalk_clicked"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 19), // "on_btnPause_clicked"
QT_MOC_LITERAL(4, 51, 24), // "on_action_Quit_triggered"
QT_MOC_LITERAL(5, 76, 23), // "on_actionOpen_triggered"
QT_MOC_LITERAL(6, 100, 28), // "on_volumeSlider_valueChanged"
QT_MOC_LITERAL(7, 129, 5), // "value"
QT_MOC_LITERAL(8, 135, 23), // "on_actionTalk_triggered"
QT_MOC_LITERAL(9, 159, 24), // "on_actionPause_triggered"
QT_MOC_LITERAL(10, 184, 12), // "stateChanged"
QT_MOC_LITERAL(11, 197, 20), // "QTextToSpeech::State"
QT_MOC_LITERAL(12, 218, 5), // "state"
QT_MOC_LITERAL(13, 224, 38), // "on_actionMove_to_speech_line_..."
QT_MOC_LITERAL(14, 263, 34), // "on_actionSkip_to_10_line_trig..."
QT_MOC_LITERAL(15, 298, 24), // "on_btnSearchText_clicked"
QT_MOC_LITERAL(16, 323, 30), // "on_txtSearchText_returnPressed"
QT_MOC_LITERAL(17, 354, 30), // "on_chkAllowScroll_stateChanged"
QT_MOC_LITERAL(18, 385, 24), // "on_btnJumpToLine_clicked"
QT_MOC_LITERAL(19, 410, 27), // "on_boxJumpLine_valueChanged"
QT_MOC_LITERAL(20, 438, 18), // "on_btnStop_clicked"
QT_MOC_LITERAL(21, 457, 25), // "on_boxVolume_valueChanged"
QT_MOC_LITERAL(22, 483, 28), // "on_boxVolume_editingFinished"
QT_MOC_LITERAL(23, 512, 30), // "on_boxJumpLine_editingFinished"
QT_MOC_LITERAL(24, 543, 24), // "on_actionAbout_triggered"
QT_MOC_LITERAL(25, 568, 28), // "on_actionVolume_Up_triggered"
QT_MOC_LITERAL(26, 597, 30), // "on_actionVolume_Down_triggered"
QT_MOC_LITERAL(27, 628, 30), // "on_boxSpeechSpeed_valueChanged"
QT_MOC_LITERAL(28, 659, 33), // "on_boxSpeechSpeed_editingFini..."
QT_MOC_LITERAL(29, 693, 39) // "on_actionStart_at_last_speech..."

    },
    "MainWindow\0on_btnTalk_clicked\0\0"
    "on_btnPause_clicked\0on_action_Quit_triggered\0"
    "on_actionOpen_triggered\0"
    "on_volumeSlider_valueChanged\0value\0"
    "on_actionTalk_triggered\0"
    "on_actionPause_triggered\0stateChanged\0"
    "QTextToSpeech::State\0state\0"
    "on_actionMove_to_speech_line_triggered\0"
    "on_actionSkip_to_10_line_triggered\0"
    "on_btnSearchText_clicked\0"
    "on_txtSearchText_returnPressed\0"
    "on_chkAllowScroll_stateChanged\0"
    "on_btnJumpToLine_clicked\0"
    "on_boxJumpLine_valueChanged\0"
    "on_btnStop_clicked\0on_boxVolume_valueChanged\0"
    "on_boxVolume_editingFinished\0"
    "on_boxJumpLine_editingFinished\0"
    "on_actionAbout_triggered\0"
    "on_actionVolume_Up_triggered\0"
    "on_actionVolume_Down_triggered\0"
    "on_boxSpeechSpeed_valueChanged\0"
    "on_boxSpeechSpeed_editingFinished\0"
    "on_actionStart_at_last_speech_triggered"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      25,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  139,    2, 0x08 /* Private */,
       3,    0,  140,    2, 0x08 /* Private */,
       4,    0,  141,    2, 0x08 /* Private */,
       5,    0,  142,    2, 0x08 /* Private */,
       6,    1,  143,    2, 0x08 /* Private */,
       8,    0,  146,    2, 0x08 /* Private */,
       9,    0,  147,    2, 0x08 /* Private */,
      10,    1,  148,    2, 0x08 /* Private */,
      13,    0,  151,    2, 0x08 /* Private */,
      14,    0,  152,    2, 0x08 /* Private */,
      15,    0,  153,    2, 0x08 /* Private */,
      16,    0,  154,    2, 0x08 /* Private */,
      17,    1,  155,    2, 0x08 /* Private */,
      18,    0,  158,    2, 0x08 /* Private */,
      19,    1,  159,    2, 0x08 /* Private */,
      20,    0,  162,    2, 0x08 /* Private */,
      21,    1,  163,    2, 0x08 /* Private */,
      22,    0,  166,    2, 0x08 /* Private */,
      23,    0,  167,    2, 0x08 /* Private */,
      24,    0,  168,    2, 0x08 /* Private */,
      25,    0,  169,    2, 0x08 /* Private */,
      26,    0,  170,    2, 0x08 /* Private */,
      27,    1,  171,    2, 0x08 /* Private */,
      28,    0,  174,    2, 0x08 /* Private */,
      29,    0,  175,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 11,   12,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_btnTalk_clicked(); break;
        case 1: _t->on_btnPause_clicked(); break;
        case 2: _t->on_action_Quit_triggered(); break;
        case 3: _t->on_actionOpen_triggered(); break;
        case 4: _t->on_volumeSlider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->on_actionTalk_triggered(); break;
        case 6: _t->on_actionPause_triggered(); break;
        case 7: _t->stateChanged((*reinterpret_cast< QTextToSpeech::State(*)>(_a[1]))); break;
        case 8: _t->on_actionMove_to_speech_line_triggered(); break;
        case 9: _t->on_actionSkip_to_10_line_triggered(); break;
        case 10: _t->on_btnSearchText_clicked(); break;
        case 11: _t->on_txtSearchText_returnPressed(); break;
        case 12: _t->on_chkAllowScroll_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: _t->on_btnJumpToLine_clicked(); break;
        case 14: _t->on_boxJumpLine_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->on_btnStop_clicked(); break;
        case 16: _t->on_boxVolume_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: _t->on_boxVolume_editingFinished(); break;
        case 18: _t->on_boxJumpLine_editingFinished(); break;
        case 19: _t->on_actionAbout_triggered(); break;
        case 20: _t->on_actionVolume_Up_triggered(); break;
        case 21: _t->on_actionVolume_Down_triggered(); break;
        case 22: _t->on_boxSpeechSpeed_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 23: _t->on_boxSpeechSpeed_editingFinished(); break;
        case 24: _t->on_actionStart_at_last_speech_triggered(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 7:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QTextToSpeech::State >(); break;
            }
            break;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 25)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 25;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 25)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 25;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
