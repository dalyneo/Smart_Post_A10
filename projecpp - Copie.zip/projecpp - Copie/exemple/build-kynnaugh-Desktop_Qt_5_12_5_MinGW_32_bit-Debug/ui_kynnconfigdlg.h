/********************************************************************************
** Form generated from reading UI file 'kynnconfigdlg.ui'
**
** Created by: Qt User Interface Compiler version 5.12.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_KYNNCONFIGDLG_H
#define UI_KYNNCONFIGDLG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_KynnConfigDlg
{
public:
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QListView *listHints;
    QHBoxLayout *horizontalLayout;
    QLineEdit *txtAdd;
    QPushButton *btnAdd;
    QCheckBox *checkConfidence;
    QCheckBox *checkEcho;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *KynnConfigDlg)
    {
        if (KynnConfigDlg->objectName().isEmpty())
            KynnConfigDlg->setObjectName(QString::fromUtf8("KynnConfigDlg"));
        KynnConfigDlg->setWindowModality(Qt::NonModal);
        KynnConfigDlg->resize(333, 420);
        KynnConfigDlg->setLayoutDirection(Qt::LeftToRight);
        KynnConfigDlg->setSizeGripEnabled(true);
        KynnConfigDlg->setModal(true);
        gridLayout = new QGridLayout(KynnConfigDlg);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(KynnConfigDlg);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout->addWidget(label);

        listHints = new QListView(KynnConfigDlg);
        listHints->setObjectName(QString::fromUtf8("listHints"));
        QSizePolicy sizePolicy(QSizePolicy::MinimumExpanding, QSizePolicy::MinimumExpanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(listHints->sizePolicy().hasHeightForWidth());
        listHints->setSizePolicy(sizePolicy);
        listHints->setMinimumSize(QSize(286, 240));
        listHints->setMaximumSize(QSize(286, 240));
        listHints->setLineWidth(1);
        listHints->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        listHints->setSizeAdjustPolicy(QAbstractScrollArea::AdjustIgnored);
        listHints->setAutoScroll(false);
        listHints->setAlternatingRowColors(true);
        listHints->setSelectionBehavior(QAbstractItemView::SelectRows);
        listHints->setVerticalScrollMode(QAbstractItemView::ScrollPerItem);
        listHints->setHorizontalScrollMode(QAbstractItemView::ScrollPerItem);
        listHints->setResizeMode(QListView::Adjust);
        listHints->setSelectionRectVisible(true);

        verticalLayout->addWidget(listHints);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        txtAdd = new QLineEdit(KynnConfigDlg);
        txtAdd->setObjectName(QString::fromUtf8("txtAdd"));

        horizontalLayout->addWidget(txtAdd);

        btnAdd = new QPushButton(KynnConfigDlg);
        btnAdd->setObjectName(QString::fromUtf8("btnAdd"));
        btnAdd->setLayoutDirection(Qt::LeftToRight);

        horizontalLayout->addWidget(btnAdd);


        verticalLayout->addLayout(horizontalLayout);

        checkConfidence = new QCheckBox(KynnConfigDlg);
        checkConfidence->setObjectName(QString::fromUtf8("checkConfidence"));
        checkConfidence->setChecked(true);

        verticalLayout->addWidget(checkConfidence);

        checkEcho = new QCheckBox(KynnConfigDlg);
        checkEcho->setObjectName(QString::fromUtf8("checkEcho"));
        checkEcho->setChecked(true);

        verticalLayout->addWidget(checkEcho);


        gridLayout->addLayout(verticalLayout, 0, 0, 1, 1);

        buttonBox = new QDialogButtonBox(KynnConfigDlg);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        QSizePolicy sizePolicy1(QSizePolicy::Maximum, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(buttonBox->sizePolicy().hasHeightForWidth());
        buttonBox->setSizePolicy(sizePolicy1);
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        gridLayout->addWidget(buttonBox, 9, 0, 1, 1);


        retranslateUi(KynnConfigDlg);
        QObject::connect(buttonBox, SIGNAL(accepted()), KynnConfigDlg, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), KynnConfigDlg, SLOT(reject()));

        QMetaObject::connectSlotsByName(KynnConfigDlg);
    } // setupUi

    void retranslateUi(QDialog *KynnConfigDlg)
    {
        KynnConfigDlg->setWindowTitle(QApplication::translate("KynnConfigDlg", "Kynnaugh Plugin Settings", nullptr));
        label->setText(QApplication::translate("KynnConfigDlg", "Hints, e.g. proper nouns for speech recognition", nullptr));
        btnAdd->setText(QApplication::translate("KynnConfigDlg", "Add", nullptr));
        checkConfidence->setText(QApplication::translate("KynnConfigDlg", "Display Confidence intervals (0 - 100)?", nullptr));
        checkEcho->setText(QApplication::translate("KynnConfigDlg", "Print transcriptions to chat for all users to see?", nullptr));
    } // retranslateUi

};

namespace Ui {
    class KynnConfigDlg: public Ui_KynnConfigDlg {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_KYNNCONFIGDLG_H
