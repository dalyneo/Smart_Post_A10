#ifndef KDECONNECT_SMS_HELPER_H
#define KDECONNECT_SMS_HELPER_H

#define App reinterpret_cast<Application *>(Application::instance())

#endif //KDECONNECT_SMS_HELPER_H
