#ifndef CONSTANTS_H
#define CONSTANTS_H

#define CONFIDENCE_FLAG "wantsConfidence"
#define ECHO_FLAG       "wantsEcho"
#define HINTS_SETTING   "hints"

#endif // CONSTANTS_H
