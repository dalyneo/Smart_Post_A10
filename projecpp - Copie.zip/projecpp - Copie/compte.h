#ifndef COMPTE_H
#define COMPTE_H
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
class compte
{
public:
    compte();
    compte(int,QString,QString);
    int get_cin();
    QString get_type() ;
    QString get_solde() ;
    QString get_ref() ;
    bool ajouter();
    bool modifier();
    QSqlQueryModel * afficher();
    QSqlQueryModel * afficherarchives();
    bool supprimer(int);
    QSqlQueryModel * tri() ;
private:
    int cin;
    QString type,solde,ref;
};

#endif // COMPTE_H
