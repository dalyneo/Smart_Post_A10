#include "carte.h"
#include <QDebug>
#include "connection.h"
#include "carte.h"
carte::carte()
{
cin=0;
email="";
solde="" ;
type="";
}
carteh::carteh()
{
cin=0;
datee="";
fn="";
}
carte::carte(int cin,QString email,QString solde,QString type)
{
  this->cin=cin;
  this->email=email ;
  this->solde=solde ;
   this->type=type ;
}
carteh::carteh(int cin,QString datee,QString fn)
{
    this->cin=cin;
    this->datee=datee;
    this->fn=fn ;
}
int carte::get_cin(){return  cin;}
QString carte::get_type(){return type;}
QString carte::get_email(){return email;}
QString carte::get_solde(){return  solde;}
QString carteh::get_datee(){return  datee;}
QString carteh::get_fn(){return  fn;}
int carteh::get_cin(){return  cin;}
bool carte::ajouter()
{
QSqlQuery query;
QString res= QString::number(cin);
query.prepare("INSERT INTO carte (CIN, EMAIL, SOLDE, TYPE) "
                    "VALUES (:cin, :email, :solde, :type)");
query.bindValue(":cin", res);
query.bindValue(":email", email);
query.bindValue(":solde", solde);
query.bindValue(":type", type);
return    query.exec();
}
bool carteh::ajoutehis()
{
    QSqlQuery query;
    QString res= QString::number(cin);
    query.prepare("INSERT INTO historique (CIN, DATEE, FN) "
                  "VALUES (:cin, :datee, :fn)");
    query.bindValue(":cin", res);
    query.bindValue(":datee", datee);
    query.bindValue(":fn", fn);
    return    query.exec();
}
bool carteh::modifierhis()
{
    QSqlQuery query;
    QString res= QString::number(cin);
    query.prepare("UPDATE historique SET datee='"+datee+"',fn='"+fn+"' where cin='"+res+"'  ;");
    query.bindValue(":cin",cin);
    query.bindValue(":datee", datee);
    query.bindValue(":fn", fn);
    return    query.exec();
}
bool carte::modifier()
{
    QSqlQuery query;
    QString res= QString::number(cin);
    query.prepare("UPDATE carte SET email='"+email+"',solde='"+solde+"',type='"+type+"' where cin='"+res+"'  ;");
    query.bindValue(":cin",cin);
    query.bindValue(":email", email);
    query.bindValue(":solde", solde);
     query.bindValue(":type", type);
    return    query.exec();
}

QSqlQueryModel * carte::afficher()
{QSqlQueryModel * model= new QSqlQueryModel();
model->setQuery("select * from carte");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("CIN"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("email"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("Solde"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("Numero"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("Type du carte"));
    return model;
}

QSqlQueryModel * carteh::afficherhis()
{
    QSqlQueryModel * model= new QSqlQueryModel();
    model->setQuery("select * from historique");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("CIN"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("date "));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("fonction "));
        return model;

}



bool carte::supprimer(int ciin)
{
QSqlQuery query;
QString res= QString::number(ciin);
query.prepare("Delete from carte where CIN = :cin ");
query.bindValue(":cin", res);
return    query.exec();
}

bool carte::rechercher(int ciin)
{
    QSqlQuery query;
    QString res= QString::number(ciin);
query.prepare("SELECT cin FROM carte WHERE cin='"+res+"' ");
query.bindValue(":cin", res);
return    query.exec();
}
QSqlQueryModel * carte::tri()
{
    QSqlQueryModel * model= new QSqlQueryModel();
    model->setQuery("select * from carte order by cin asc;");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("CIN"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("email"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Solde"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("Numero"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("Type du carte"));
        return model;
}

