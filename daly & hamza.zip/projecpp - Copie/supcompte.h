#ifndef SUPCOMPTE_H
#define SUPCOMPTE_H
#include "compte.h"
#include <QDialog>
#include <QMainWindow>
#include <QTimer>
namespace Ui {
class supcompte;
}

class supcompte : public QDialog
{
    Q_OBJECT

public:
    explicit supcompte(QWidget *parent = nullptr);
    ~supcompte();

private slots:
//     void on_pb_supprimer_clicked();

     void on_pushButton_clicked();

private:
    Ui::supcompte *ui;
     compte tmpcompte;
};


#endif // SUPCOMPTE_H
