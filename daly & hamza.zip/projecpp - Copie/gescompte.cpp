#include "carte.h"
#include "gescompte.h"
#include "ui_gescompte.h"
#include "mainwindow.h"
#include "gescarte.h"
#include "ui_gescarte.h"
#include <QMessageBox>
#include "compte.h"
#include <QPrinter>
#include <QPdfWriter>
#include <QApplication>
#include <QMessageBox>
#include <QDesktopServices>
#include <QUrl>
#include <QDebug>
#include <QTextBrowser>
#include <QFileDialog>
#include <QtTextToSpeech>
#include <QTextBlock>
#include <cstdlib>
Gescompte::Gescompte(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Gescompte)
{
    ui->setupUi(this);
    ui->comboBox->addItem("Compte epargne");
    ui->comboBox->addItem("Compte courant") ;

    //ui->tableView->setModel(model);
     ui->tableView->setModel(tmpcompte.afficher());
     ui->tableView->setModel(tmpcompte.afficher());//refresh
}


Gescompte::~Gescompte()
{
    delete ui;
}

void Gescompte::closeWin()
{
 this->close();
    this->deleteLater();
}

void Gescompte::on_acceuilbtn_clicked()
{

    MainWindow *main;
    main = new MainWindow();
    main->showFullScreen();
    delay = new QTimer(this);
   connect(delay,SIGNAL(timeout()),this,SLOT(closeWin()));
   delay->start(500);


}

void Gescompte::on_quitter_clicked()
{

            this->close();
   // this->resize(1280,960) ;

}

void Gescompte::on_pushButton_3_clicked()
{
    gescarte *ges;
    ges = new gescarte();
     ges->showFullScreen();
     delay = new QTimer(this);
    connect(delay,SIGNAL(timeout()),this,SLOT(closeWin()));
    delay->start(500);
    ui->tableView->setModel(tmpcompte.afficher());
    ui->tableView->setModel(tmpcompte.afficher());//refresh
}
void Gescompte::on_pushButton_7_clicked()
{
    QString cinn = ui->rcpt->text();
    QSqlQueryModel * model= new QSqlQueryModel();
    QSqlQuery* qry=new QSqlQuery();
    qry->prepare("SELECT * from compte where cin= :cinn");
    qry->bindValue(":cinn",cinn);
    qry->exec();
   if(qry->next())
   {
       erreur->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/compteexiste.mp3")) ;
           erreur->setVolume(100) ;
           erreur->play() ;
           model->setQuery(*qry);
           ui->tableView->setModel(model) ;

   }
   else
   {
       erreur->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/comptenot.mp3")) ;
           erreur->setVolume(100) ;
           erreur->play() ;
   }

}
void Gescompte::on_pushButton_4_clicked()
{
    srand (time(NULL));
    bool test3=false ;
    QString cinn = ui->lineEdit_cin->text();

    if(sizeof(cinn)>=9 && sizeof(cinn)<9)
    {
        erreur->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/erreur.mp3")) ;
            erreur->setVolume(100) ;
            erreur->play() ;
        QMessageBox::critical(nullptr, QObject::tr("Erreur CIN"),
                          QObject::tr("CIN composée de 8 chiffre.\n"
                                      "Click Cancel to exit."), QMessageBox::Cancel);
    }
    else
    {
    QString type = ui->comboBox->currentText() ;

    QSqlQuery* qry=new QSqlQuery();
    QSqlQuery* qry1=new QSqlQuery();
    QSqlQuery* qry2=new QSqlQuery();
    QSqlQuery *qry3=new QSqlQuery();
    QSqlQuery *qry4=new QSqlQuery();
    qry4->prepare("select * from RIB") ;
    /*if(qry4->exec())
    {
        while(qry4->next())
        {
            QString     ref = qry4->value(0).toString() ;
            qry1->prepare("INSERT INTO compte (REF) "
                         "VALUES (:ref)");
                qry1->bindValue(":ref",ref);
                qry1->exec();
              qry3->prepare("Delete from RIB where rib = :ref ");
                      qry3->bindValue(":ref", ref);
                      qry3->exec();
        }
    }*/
               int solde = ui->lineEdit_solde_1->text().toInt();
    qry->prepare("select * from client where cin = '"+cinn+"' ");
    if(qry->exec()&&(qry4->exec()))
    {
        while (qry->next()&&qry4->next())
        {
              // QString res= QString::number(cin);
            QString     ref = qry4->value(0).toString() ;
             QString     cin = qry->value(0).toString() ;
             QString     email=qry->value(0).toString();
              qry1->prepare("INSERT INTO compte (CIN,  TYPE, REF, SOLDE) "
                           "VALUES (:cin, :type, :ref, :solde)");
                  qry1->bindValue(":cin",cin);
                  qry1->bindValue(":type", type);
                  qry1->bindValue(":ref",ref);
                  qry1->bindValue(":solde", solde);
            qry2->prepare("Delete from RIB where rib = :ref ");
                    qry2->bindValue(":ref", ref);
                    qry2->exec();
                 if(ui->active->isChecked())
                  {
                test3=true ;
                int ref=rand() ;
                QString exemple="Compte courant";
                QString typee ;
                if(exemple==type)
                typee="Carte Visa";
                else
                typee="Carte e-DINAR SMART";


                  qry3->prepare("INSERT INTO carte (CIN, EMAIL, SOLDE, REF, TYPE) "
                                      "VALUES (:cin,  :email, :solde, :ref, :type)");
                  qry3->bindValue(":cin", cin);
                  qry3->bindValue(":email", email);
                  qry3->bindValue(":solde", solde);
                  qry3->bindValue(":ref", ref);
                  qry3->bindValue(":type", typee);
                  qry3->exec();
                  QDate d = QDate::currentDate() ;
                   QString datee =d.toString("dd / MM / yyyy ") ;
                   QString fn="ajouter" ;
                  carteh cc(cinn,datee,fn) ;
                  bool test2=cc.ajoutehis() ;
                  erreur->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/carteajouter.mp3")) ;
                      erreur->setVolume(100) ;
                      erreur->play() ;
                  QMessageBox::information(nullptr, QObject::tr("Ajouter une carte"),
                                    QObject::tr("carte ajouté.\n"
                                                "Click Cancel to exit."), QMessageBox::Cancel);
                  }
        }

    }




       // qry1->exec() ;
         if((qry1->exec()) && (test3=true))
        {
            erreur->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/ajoutcompte.mp3")) ;
                erreur->setVolume(100) ;
                erreur->play() ;
           QMessageBox::information(nullptr, QObject::tr("Ajouter un compte"),
                             QObject::tr("compte ajouté.\n"
                                         "Click Cancel to exit."), QMessageBox::Cancel);
           ui->tableView->setModel(tmpcompte.afficher());
           ui->tableView->setModel(tmpcompte.afficher());//refresh
        }
        else if((qry1->exec())&& (test3=false))
        {
            erreur->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/ajoutcompte.mp3")) ;
                erreur->setVolume(100) ;
                erreur->play() ;
           QMessageBox::information(nullptr, QObject::tr("Ajouter un compte"),
                             QObject::tr("compte ajouté.\n"
                                         "Click Cancel to exit."), QMessageBox::Cancel);
           ui->tableView->setModel(tmpcompte.afficher());
           ui->tableView->setModel(tmpcompte.afficher());//refresh
        }
else
       {
            erreur->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/erreur.mp3")) ;
                erreur->setVolume(100) ;
                erreur->play() ;
           QMessageBox::critical(nullptr, QObject::tr("Ajouter un compte"),
                       QObject::tr("Erreur !.\n"
                                   "Click Cancel to exit."), QMessageBox::Cancel);
       }
             }
    }


void Gescompte::on_pushButton_5_clicked()
{
    QString cin = ui->lineEdit_cin->text();
    QString type= ui->comboBox->currentText();
    QString solde = ui->lineEdit_solde_1->text() ;
  compte c(cin,type,solde);
  bool test=c.modifier();
  if(test)
{
      erreur->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/comptemodifier.mp3")) ;
          erreur->setVolume(100) ;
          erreur->play() ;
QMessageBox::information(nullptr, QObject::tr("Modifier compte"),
                  QObject::tr("compte modifier.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}
  else
  {
      erreur->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/erreur.mp3")) ;
          erreur->setVolume(100) ;
          erreur->play() ;
      QMessageBox::critical(nullptr, QObject::tr("Modifier compte"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);
  }
    ui->tableView->setModel(tmpcompte.afficher());
    ui->tableView->setModel(tmpcompte.afficher());//refresh
}





void Gescompte::on_pushButton_6_clicked()
{
    ui->tableView->setModel(tmpcompte.tri());
    ui->tableView->setModel(tmpcompte.tri());//refresh
}

void Gescompte::on_imprimer_clicked()
{
    QString str;
    str.append("<html><head></head><body><center>"+QString("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;;<font size=""10"" color =""red""> GESTION DES COMPTES </font><br /> <br /> "));
    str.append("<table border=1><tr>");
    str.append("<td>"+QString("  ")+"&nbsp;&nbsp;<font color =""blue""  size=""10"">Cin</font>&nbsp;&nbsp;"+"</td>");
    str.append("<td>"+QString("  ")+"&nbsp;&nbsp;<font color =""blue""  size=""10"">Type de compte</font>&nbsp;&nbsp;"+"</td>");
    str.append("<td>"+QString("&nbsp;&nbsp;<font color =""blue""  size=""20"">RIB</font>&nbsp;&nbsp;")+"</td>");
    str.append("<td>"+QString("&nbsp;&nbsp;<font color =""blue""  size=""10"">Solde</font>&nbsp;&nbsp;")+"</td>");

    QSqlQuery * query=new QSqlQuery();
    query->exec("SELECT cin,type,ref,solde FROM compte");
    while(query->next())
    {
        str.append("<tr><td>");
        str.append("&nbsp;&nbsp;<font color =""green"" size= ""10"">"+query->value(0).toString()+"&nbsp;&nbsp;");
        str.append("</td><td>");
        str.append("&nbsp;&nbsp;<font color =""green""  size=""10"">"+query->value(1).toString()+"&nbsp;&nbsp;");
        str.append("</td><td>");
        str.append("&nbsp;&nbsp;<font color =""green"" size=""10"">"+query->value(2).toString()+"&nbsp;&nbsp;");
         str.append("</td><td>");
        str.append("&nbsp;&nbsp;<font color =""green"" size= ""10"">"+query->value(3).toString()+"&nbsp;&nbsp;");
        str.append("</td></tr>");

}

    str.append("</table></center><body></html>");

    QPrinter printer;
    printer.setOrientation(QPrinter::Portrait);
    printer.setOutputFormat(QPrinter::PdfFormat);
    printer.setPaperSize(QPrinter::A4);

    QString path= QFileDialog::getSaveFileName(NULL,"imprimer","gestion des comptes","PDF(*.pdf");
     if(path.isEmpty()) return;
     printer.setOutputFileName(path);
     QTextDocument doc;
     doc.setHtml(str);
     doc.print(&printer);
}

void Gescompte::on_pushButton_8_clicked()
{
    QString cin = ui->lineEdit_id_2->text();
    QSqlQuery* qry=new QSqlQuery();
    QSqlQuery* qry1=new QSqlQuery();
    qry->prepare("SELECT * from compte where cin='"+cin+"'");
    if(qry->exec())
    {
        while (qry->next())
        {
             QString     cin = qry->value(0).toString() ;
             QString     nom = qry->value(0).toString() ;
             QString     prenom = qry->value(0).toString() ;
             QString     adresse = qry->value(0).toString() ;
             QString     type = qry->value(0).toString() ;
              int     ref = qry->value(0).toInt() ;
              int     solde = qry->value(0).toInt() ;
              QString res1= QString::number(ref);
              QString res2= QString::number(solde);
              qry1->prepare("INSERT INTO archives (CIN, NOM, PRENOM, ADRESSE, TYPE, REF, SOLDE) "
                           "VALUES (:cin, :nom, :prenom, :adresse, :type, :ref, :solde)");
                 qry1->bindValue(":cin", cin);
                  qry1->bindValue(":nom", nom);
                  qry1->bindValue(":prenom", prenom);
                  qry1->bindValue(":adresse", adresse);
                  qry1->bindValue(":type", type);
                  qry1->bindValue(":ref", res1);
                  qry1->bindValue(":solde", res2);
                  qry1->exec() ;
        }

    }
    bool test=tmpcompte.supprimer(cin);
    if(test)
    {
        // ui->tableView->setModel(tmpcompte.afficher());//refresh
        erreur->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/comptesupprimer.mp3")) ;
            erreur->setVolume(100) ;
            erreur->play() ;
        QMessageBox::information(nullptr, QObject::tr("Supprimer un compte"),
                    QObject::tr("Compte supprimé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
    {
        erreur->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/erreur.mp3")) ;
            erreur->setVolume(100) ;
            erreur->play() ;
        QMessageBox::critical(nullptr, QObject::tr("Supprimer un Compte"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    }
    ui->tableView->setModel(tmpcompte.afficher());
    ui->tableView->setModel(tmpcompte.afficher());//refresh
}



void Gescompte::on_act_clicked()
{
    ui->tableView->setModel(tmpcompte.afficher());
    ui->tableView->setModel(tmpcompte.afficher());//refresh
}




void Gescompte::on_tableView_activated(const QModelIndex &index)
{
    QString cinn = ui->tableView->model()->data(index).toString() ;
   QSqlQuery qry;
   qry.prepare("SELECT * from compte where cin = '"+cinn+"'") ;
   if (qry.exec())
   {
       while (qry.next()) {
           ui->lineEdit_cin->setText(qry.value(0).toString()) ;
           ui->comboBox->setCurrentText(qry.value(1).toString());
           ui->lineEdit_solde_1->setText(qry.value(3).toString());
       }
   }
   QSqlQuery qry1;
   qry1.prepare("SELECT * from compte where cin = '"+cinn+"'") ;
   if (qry1.exec())
   {
       while (qry1.next()) {
           ui->lineEdit_id_2->setText(qry1.value(0).toString()) ;
       }
   }
   ui->tableView->setModel(tmpcompte.afficher());
   ui->tableView->setModel(tmpcompte.afficher());//refresh
}

void Gescompte::on_archives_clicked()
{
    ui->tableView->setModel(tmpcompte.afficherarchives()) ;
    ui->tableView->setModel(tmpcompte.afficherarchives());//refresh
}



void Gescompte::on_pushButton_2_clicked()
{
    gescarte *ges;
    ges = new gescarte();
     ges->showFullScreen();
     delay = new QTimer(this);
    connect(delay,SIGNAL(timeout()),this,SLOT(closeWin()));
    delay->start(500);
}

void Gescompte::on_quitter_2_clicked()
{
    Gescompte *ges;
    ges = new Gescompte();
     ges->show();
     delay = new QTimer(this);
    connect(delay,SIGNAL(timeout()),this,SLOT(closeWin()));
    delay->start(500);
}

