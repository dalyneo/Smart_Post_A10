#include "gescompte.h"
#include "ui_gescompte.h"
#include "ui_gescarte.h"
#include "compte.h"
#include "gescarte.h"
#include <QMessageBox>
#include "carte.h"
#include "mainwindow.h"
#include "gescarte.h"
#include "smtp.h"
#include <QTimer>
#include <QDateTime>
#include <QDate>
#include <QStringList>
#include <QString>
#include <cstdlib>
/*#include <stdexcept>
#include <fstream>
#include <sstream>
#include "Utility.hpp"
#include <iostream>
#include <QWidget>
#include <vector>*/
gescarte::gescarte(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::gescarte)
{

    ui->setupUi(this);
   /* QTimer *timer=new QTimer(this) ;
    connect(timer,SIGNAL(timeout()),this,SLOT(showTime())) ;
    timer->start() ;*/
    ui->comboBox->addItem("DINARPOST VISA");
    ui->comboBox->addItem("E-DINAR SMART") ;
    ui->comboBox->addItem("E-DINAR UNIVERSEL");
    ui->tableView->setModel(tmpcarte.afficher());
    ui->tableView->setModel(tmpcarte.afficher());//refresh
}

gescarte::~gescarte()
{
    delete ui;
}
void gescarte::closeWin()
{
 this->close();
    this->deleteLater();
}
void gescarte::on_pushButton_2_clicked()
{
    Gescompte *ges;
    ges = new Gescompte();
     ges->showFullScreen();
     delay = new QTimer(this);
    connect(delay,SIGNAL(timeout()),this,SLOT(closeWin()));
    delay->start(500);
    ui->tableView->setModel(tmpcarte.afficher());
    ui->tableView->setModel(tmpcarte.afficher());//refresh
}



void gescarte::on_acceuilbtn_clicked()
{
    MainWindow *main;
    main = new MainWindow();
    main->showFullScreen();
    delay = new QTimer(this);
   connect(delay,SIGNAL(timeout()),this,SLOT(closeWin()));
   delay->start(500);
   ui->tableView->setModel(tmpcarte.afficher());
   ui->tableView->setModel(tmpcarte.afficher());//refresh

}

void gescarte::on_quitter_clicked()
{

           this->close();


}

void gescarte::on_pushButton_5_clicked()
{
    srand (time(NULL));
    QDate d = QDate::currentDate() ;
     QString datee =d.toString("dd / MM / yyyy ") ;
     QString fn="ajouter" ;
    QString cinn = ui->lineEdit_cin->text();
    int ref=rand();
  carteh cc(cinn,datee,fn) ;
  bool test1=cc.ajoutehis() ;
  QSqlQuery* qry=new QSqlQuery();
  QSqlQuery* qry1=new QSqlQuery();
  qry->prepare("select * from client where cin = '"+cinn+"' ");
  if(qry->exec())
  {
      while (qry->next())
      {
            // QString res= QString::number(cin);
           QString     cin = qry->value(0).toString() ;
           QString     email=qry->value(0).toString();
            qry1->prepare("INSERT INTO carte (CIN, EMAIL, SOLDE, REF, TYPE) "
                          "VALUES (:cin, :email, :solde, :ref, :type)");
                int solde = ui->lineEdit_solde->text().toInt();
                 QString type = ui->comboBox->currentText() ;
                qry1->bindValue(":cin",cin);
                qry1->bindValue(":email", email);
                qry1->bindValue(":solde",solde);
                qry1->bindValue(":ref",ref);
                qry1->bindValue(":type",type);
      }
     // qry1->exec() ;
      if(qry1->exec())
      {
          erreur->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/carteajouter.mp3")) ;
              erreur->setVolume(100) ;
              erreur->play() ;
         QMessageBox::information(nullptr, QObject::tr("Ajouter une carte"),
                           QObject::tr("carte ajouté.\n"
                                       "Click Cancel to exit."), QMessageBox::Cancel);
         ui->tableView->setModel(tmpcarte.afficher());
         ui->tableView->setModel(tmpcarte.afficher());//refresh
      }
else
     {
          erreur->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/erreur.mp3")) ;
              erreur->setVolume(100) ;
              erreur->play() ;
         QMessageBox::critical(nullptr, QObject::tr("Ajouter une carte"),
                     QObject::tr("Erreur !.\n"
                                 "Click Cancel to exit."), QMessageBox::Cancel);
     }
  }

}

void gescarte::on_pushButton_8_clicked()
{
    bool test2=false ;

    QDate d = QDate::currentDate() ;
     QString datee =d.toString("dd / MM / yyyy ") ;
     QString fn="modifier" ;
     QString type= ui->comboBox->currentText();
         QString cin = ui->lineEdit_cin->text();
         QString email= ui->lineEdit4->text() ;
         QString solde = ui->lineEdit_solde->text();
       QString email_reverse ;
            for (QString::iterator it = email.begin(); it != email.end(); ++it)
                email_reverse.push_front(*it);

    if(email_reverse.startsWith( "moc.liamg@" ))
            test2=true ;
    else
        test2=false ;
    carteh cc(cin,datee,fn) ;
    if(test2==false)
    {
        erreur->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/erreur.mp3")) ;
            erreur->setVolume(100) ;
            erreur->play() ;
        QMessageBox::critical(nullptr, QObject::tr("email de la carte"),
                    QObject::tr("il faut @gmail.com !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    }
    else
    {
    bool test1=cc.modifierhis() ;
  carte c(cin,email,solde,type);
  bool test=c.modifier();
  if(test && test1)
{
      erreur->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/cartemodifier.mp3")) ;
          erreur->setVolume(100) ;
          erreur->play() ;
QMessageBox::information(nullptr, QObject::tr("Modifier carte"),
                  QObject::tr("carte modifier.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}
  else
  {
      erreur->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/erreur.mp3")) ;
          erreur->setVolume(100) ;
          erreur->play() ;
      QMessageBox::critical(nullptr, QObject::tr("Modifier carte"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);
  }
}
  ui->tableView->setModel(tmpcarte.afficher());
  ui->tableView->setModel(tmpcarte.afficher());//refresh
}



void gescarte::on_pushButton_6_clicked()
{
    QDate d = QDate::currentDate() ;
     QString datee =d.toString("dd / MM / yyyy ") ;
     QString fn="supprimer" ;
    QString cin = ui->lineEdit_id_2->text();
    carteh cc(cin,datee,fn) ;
    bool test1=cc.modifierhis() ;
    bool test=tmpcarte.supprimer(cin);
    if(test && test1)
    {
        // ui->tableView->setModel(tmpcompte.afficher());//refresh
        erreur->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/cartesupprimer.mp3")) ;
            erreur->setVolume(100) ;
            erreur->play() ;
        QMessageBox::information(nullptr, QObject::tr("Supprimer une carte"),
                    QObject::tr("carte supprimé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
    {
        erreur->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/erreur.mp3")) ;
            erreur->setVolume(100) ;
            erreur->play() ;
        QMessageBox::critical(nullptr, QObject::tr("Supprimer une carte"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    }
    ui->tableView->setModel(tmpcarte.afficher());
    ui->tableView->setModel(tmpcarte.afficher());//refresh
}

void gescarte::on_pushButton_4_clicked()
{
    ui->tableView->setModel(tmpcarte.tri());
    ui->tableView->setModel(tmpcarte.tri());//refresh
}

void gescarte::on_pushButton_7_clicked()
{
    int cinn = ui->rcpt_2->text().toInt();
    QSqlQueryModel * model= new QSqlQueryModel();
    QSqlQuery* qry=new QSqlQuery();
    qry->prepare("SELECT * from carte where cin like concat (:cinn,'%')");
    qry->bindValue(":cinn",cinn);
    qry->exec();
    if(qry->next())
    {
        erreur->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/carteexiste.mp3")) ;
            erreur->setVolume(100) ;
            erreur->play() ;
            model->setQuery(*qry);
            ui->tableView->setModel(model) ;
    }
    else
    {
        erreur->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/cartenot.mp3")) ;
            erreur->setVolume(100) ;
            erreur->play() ;
    }
}

void gescarte::on_send_clicked()
{
    erreur->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/email.mp3")) ;
        erreur->setVolume(100) ;
        erreur->play() ;
        Smtp* smtp = new Smtp("cpp.projet.cpp@gmail.com", "c++testc++", "smtp.gmail.com", 465);
        connect(smtp, SIGNAL(status(QString)), this, SLOT(mailSent(QString)));
            smtp->sendMail("cpp.projet.cpp@gmail.com", ui->rcpt->text() , "tableau des cartes",0);
            QMessageBox::warning( 0, tr( "Qt Simple SMTP client" ), tr( "Message sent!\n\n" ) );

}


void gescarte::on_pushButton_9_clicked()
{
    ui->tableView->setModel(tmpcarte.afficher());
    ui->tableView->setModel(tmpcarte.afficher());//refresh
}


void gescarte::on_tableView_activated(const QModelIndex &index)
{
    QString cinn = ui->tableView->model()->data(index).toString() ;
   QSqlQuery qry;
   qry.prepare("SELECT * from carte where cin = '"+cinn+"'") ;
   if (qry.exec())
   {
       while (qry.next()) {
           ui->lineEdit_cin->setText(qry.value(0).toString()) ;
           ui->lineEdit4->setText(qry.value(1).toString()) ;
           ui->lineEdit_solde->setText(qry.value(2).toString()) ;
           ui->comboBox->setCurrentText(qry.value(3).toString());
       }
   }

  QSqlQuery qry1;
  qry1.prepare("SELECT * from carte where cin = '"+cinn+"'") ;
  if (qry1.exec())
  {
      while (qry1.next()) {
          ui->lineEdit_id_2->setText(qry1.value(0).toString()) ;
      }
  }
   ui->tableView->setModel(tmpcarte.afficher());
   ui->tableView->setModel(tmpcarte.afficher());//refresh
}

void gescarte::on_historique_clicked()
{
    ui->tableView->setModel(tmpcarteh.afficherhis()) ;
    ui->tableView->setModel(tmpcarteh.afficherhis());//refresh
}




void gescarte::on_pushButton_clicked()
{

    Gescompte *ges;
    ges = new Gescompte();
     ges->showFullScreen();
     delay = new QTimer(this);
    connect(delay,SIGNAL(timeout()),this,SLOT(closeWin()));
    delay->start(500);

}

void gescarte::on_quitter_2_clicked()
{
    gescarte *ges;
    ges = new gescarte();
     ges->show();
     delay = new QTimer(this);
    connect(delay,SIGNAL(timeout()),this,SLOT(closeWin()));
    delay->start(500);

}
