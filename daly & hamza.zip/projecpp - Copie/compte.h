#ifndef COMPTE_H
#define COMPTE_H
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
class compte
{
public:
    compte();
    compte(QString,QString,QString);
    QString get_cin();
    QString get_type() ;
    QString get_solde() ;
    QString get_ref() ;
    bool ajouter();
    bool modifier();
    QSqlQueryModel * afficher();
    QSqlQueryModel * afficherarchives();
    bool supprimer(QString);
    bool rechercher(QString);
    QSqlQueryModel * tri() ;
private:

    QString cin,type,solde,ref;
};

#endif // COMPTE_H
