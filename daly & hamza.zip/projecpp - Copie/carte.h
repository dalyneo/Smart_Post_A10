#ifndef CARTE_H
#define CARTE_H


#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>

class carte
{
public:
    carte();
    carte(QString,QString,QString,QString);
    QString get_cin();
    QString get_type() ;
    QString get_email() ;
    QString get_solde() ;
    bool ajouter();
    bool modifier();
    QSqlQueryModel * afficher();
    bool supprimer(QString);
    QSqlQueryModel * tri() ;
    bool rechercher(QString) ;
private:

    QString cin,type,email,solde;
};
class carteh
{
public:
       carteh() ;
       carteh(QString,QString,QString) ;
       QString get_cin();
       QString get_datee();
       QString get_fn();
       QSqlQueryModel * afficherhis() ;
       bool ajoutehis();
       bool modifierhis() ;
private:

    QString cin,datee,fn ;
};

#endif // CARTE_H
