/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QFrame *des1;
    QPushButton *pushButton_3;
    QFrame *btn;
    QFrame *logo;
    QFrame *des2;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1185, 1072);
        QSizePolicy sizePolicy(QSizePolicy::Maximum, QSizePolicy::Maximum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        MainWindow->setStyleSheet(QString::fromUtf8("#centralwidget\n"
"{\n"
"background: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/back.png);\n"
"}\n"
"#des1\n"
"{\n"
"background:#fec424;\n"
"\n"
"}\n"
"#des2\n"
"{\n"
"background:#fec424;\n"
"\n"
"}\n"
"#logo\n"
"{\n"
"background: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/rpl.png);\n"
"}"));
        MainWindow->setAnimated(true);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        des1 = new QFrame(centralwidget);
        des1->setObjectName(QString::fromUtf8("des1"));
        des1->setGeometry(QRect(-10, 94, 6000, 41));
        des1->setFrameShape(QFrame::StyledPanel);
        des1->setFrameShadow(QFrame::Raised);
        pushButton_3 = new QPushButton(des1);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(970, -25, 301, 91));
        pushButton_3->setStyleSheet(QString::fromUtf8("*{\n"
"width: 10px;\n"
"\n"
"background-color: transparent;\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/title.png);\n"
"background: none;\n"
"border: none;\n"
"background-repeat: none;\n"
"}\n"
"\n"
"*:hover\n"
"{\n"
"width: 10px;\n"
"background-color: transparent;\n"
"\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/titlepr.png);\n"
"background: none;\n"
"border: none;\n"
"background-repeat: none;\n"
"}"));
        btn = new QFrame(centralwidget);
        btn->setObjectName(QString::fromUtf8("btn"));
        btn->setGeometry(QRect(740, 300, 209, 279));
        btn->setFrameShape(QFrame::StyledPanel);
        btn->setFrameShadow(QFrame::Raised);
        logo = new QFrame(centralwidget);
        logo->setObjectName(QString::fromUtf8("logo"));
        logo->setGeometry(QRect(20, -20, 251, 251));
        logo->setFrameShape(QFrame::StyledPanel);
        logo->setFrameShadow(QFrame::Raised);
        des2 = new QFrame(centralwidget);
        des2->setObjectName(QString::fromUtf8("des2"));
        des2->setGeometry(QRect(-10, 120, 301, 1091));
        des2->setStyleSheet(QString::fromUtf8(""));
        des2->setFrameShape(QFrame::StyledPanel);
        des2->setFrameShadow(QFrame::Raised);
        pushButton = new QPushButton(des2);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(20, 130, 261, 51));
        pushButton->setStyleSheet(QString::fromUtf8("*{\n"
"width: 10px;\n"
"\n"
"background-color: transparent;\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/btngl.png);\n"
"background: none;\n"
"border: none;\n"
"background-repeat: none;\n"
"}\n"
"\n"
"*:hover\n"
"{\n"
"width: 10px;\n"
"background-color: transparent;\n"
"\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/gg.png);\n"
"background: none;\n"
"border: none;\n"
"background-repeat: none;\n"
"}"));
        pushButton_2 = new QPushButton(des2);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(120, 830, 51, 41));
        pushButton_2->setStyleSheet(QString::fromUtf8("*{\n"
"width: 10px;\n"
"\n"
"background-color: transparent;\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/exit.png);\n"
"background: none;\n"
"border: none;\n"
"background-repeat: none;\n"
"}\n"
"\n"
"*:hover\n"
"{\n"
"width: 10px;\n"
"background-color: transparent;\n"
"\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/exit1.png);\n"
"background: none;\n"
"border: none;\n"
"background-repeat: none;\n"
"}"));
        MainWindow->setCentralWidget(centralwidget);
        des2->raise();
        des1->raise();
        btn->raise();
        logo->raise();
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1185, 26));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        pushButton_3->setText(QString());
        pushButton->setText(QString());
        pushButton_2->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
