/********************************************************************************
** Form generated from reading UI file 'gescat.ui'
**
** Created by: Qt User Interface Compiler version 5.12.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GESCAT_H
#define UI_GESCAT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_gescat
{
public:
    QWidget *centralwidget;
    QFrame *des1;
    QPushButton *acceuilbtn;
    QFrame *logo;
    QFrame *des2;
    QPushButton *pushButton;
    QPushButton *quitter;
    QPushButton *grandir;
    QPushButton *pushButton_3;
    QPushButton *pushButton_2;
    QFrame *backing;
    QFrame *motlvs;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QLineEdit *lineEdit;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLineEdit *lineEdit_idc;
    QLineEdit *lineEdit_nomc;
    QLineEdit *lineEdit_ref;
    QLineEdit *lineEdit_idc_2;
    QLineEdit *lineEdit_idc_3;
    QLineEdit *lineEdit_nomc_2;
    QLineEdit *lineEdit_ref_2;
    QTableView *tableView;
    QPushButton *pushButton_4;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *gescat)
    {
        if (gescat->objectName().isEmpty())
            gescat->setObjectName(QString::fromUtf8("gescat"));
        gescat->resize(1862, 1046);
        QSizePolicy sizePolicy(QSizePolicy::Maximum, QSizePolicy::Maximum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(gescat->sizePolicy().hasHeightForWidth());
        gescat->setSizePolicy(sizePolicy);
        gescat->setStyleSheet(QString::fromUtf8("#centralwidget\n"
"{\n"
"background: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/back.png);\n"
"}\n"
"#des1\n"
"{\n"
"background:#fec424;\n"
"\n"
"}\n"
"#des2\n"
"{\n"
"background:#fec424;\n"
"\n"
"}\n"
"#logo\n"
"{\n"
"background: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/rpl.png);\n"
"}\n"
"#backing\n"
"{\n"
"background: urlC:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/backing.png);\n"
"}\n"
"\n"
"#motlvs\n"
"{\n"
"background: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/motlvr.png);\n"
"}"));
        gescat->setAnimated(true);
        centralwidget = new QWidget(gescat);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        des1 = new QFrame(centralwidget);
        des1->setObjectName(QString::fromUtf8("des1"));
        des1->setGeometry(QRect(-10, 94, 6000, 41));
        des1->setFrameShape(QFrame::StyledPanel);
        des1->setFrameShadow(QFrame::Raised);
        acceuilbtn = new QPushButton(des1);
        acceuilbtn->setObjectName(QString::fromUtf8("acceuilbtn"));
        acceuilbtn->setGeometry(QRect(970, -25, 301, 91));
        acceuilbtn->setStyleSheet(QString::fromUtf8("*{\n"
"width: 10px;\n"
"\n"
"background-color: transparent;\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/title.png);\n"
"background: none;\n"
"border: none;\n"
"background-repeat: none;\n"
"}\n"
"\n"
"*:hover\n"
"{\n"
"width: 10px;\n"
"background-color: transparent;\n"
"\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/titlepr.png);\n"
"background: none;\n"
"border: none;\n"
"background-repeat: none;\n"
"}"));
        logo = new QFrame(centralwidget);
        logo->setObjectName(QString::fromUtf8("logo"));
        logo->setGeometry(QRect(20, -20, 251, 251));
        logo->setFrameShape(QFrame::StyledPanel);
        logo->setFrameShadow(QFrame::Raised);
        des2 = new QFrame(centralwidget);
        des2->setObjectName(QString::fromUtf8("des2"));
        des2->setGeometry(QRect(-10, 120, 301, 1091));
        des2->setStyleSheet(QString::fromUtf8(""));
        des2->setFrameShape(QFrame::StyledPanel);
        des2->setFrameShadow(QFrame::Raised);
        pushButton = new QPushButton(des2);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(20, 130, 261, 51));
        pushButton->setStyleSheet(QString::fromUtf8("*{\n"
"width: 10px;\n"
"\n"
"background-color: transparent;\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/gg.png);\n"
"background: none;\n"
"border: none;\n"
"background-repeat: none;\n"
"}\n"
"\n"
"*:hover\n"
"{\n"
"\n"
"}"));
        quitter = new QPushButton(des2);
        quitter->setObjectName(QString::fromUtf8("quitter"));
        quitter->setGeometry(QRect(120, 830, 51, 41));
        quitter->setStyleSheet(QString::fromUtf8("*{\n"
"width: 10px;\n"
"\n"
"background-color: transparent;\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/exit.png);\n"
"background: none;\n"
"border: none;\n"
"background-repeat: none;\n"
"}\n"
"*:hover\n"
"{\n"
"\n"
"}"));
        grandir = new QPushButton(des2);
        grandir->setObjectName(QString::fromUtf8("grandir"));
        grandir->setGeometry(QRect(120, 720, 51, 41));
        grandir->setStyleSheet(QString::fromUtf8("*{\n"
"width: 10px;\n"
"\n"
"background-color: transparent;\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/agrandir.png);\n"
"background: none;\n"
"border: none;\n"
"background-repeat: none;\n"
"}\n"
"\n"
"\n"
"*:hover\n"
"{\n"
"width: 10px;\n"
"background-color: transparent;\n"
"\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/exit1.png);\n"
"background: none;\n"
"border: none;\n"
"background-repeat: none;\n"
"}"));
        pushButton_3 = new QPushButton(centralwidget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(448, 150, 161, 51));
        pushButton_3->setStyleSheet(QString::fromUtf8("*{\n"
"width: 10px;\n"
"\n"
"background-color: transparent;\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/btncat.png);\n"
"background: none;\n"
"border: none;\n"
"background-repeat: none;\n"
"}\n"
"\n"
""));
        pushButton_2 = new QPushButton(centralwidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(330, 150, 121, 51));
        pushButton_2->setStyleSheet(QString::fromUtf8("*{\n"
"width: 10px;\n"
"\n"
"background-color: transparent;\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/btnprod.png);\n"
"background: none;\n"
"border: none;\n"
"background-repeat: none;\n"
"}\n"
"\n"
""));
        backing = new QFrame(centralwidget);
        backing->setObjectName(QString::fromUtf8("backing"));
        backing->setGeometry(QRect(290, 210, 2001, 71));
        backing->setFrameShape(QFrame::StyledPanel);
        backing->setFrameShadow(QFrame::Raised);
        motlvs = new QFrame(backing);
        motlvs->setObjectName(QString::fromUtf8("motlvs"));
        motlvs->setGeometry(QRect(-130, -10, 541, 91));
        motlvs->setFrameShape(QFrame::StyledPanel);
        motlvs->setFrameShadow(QFrame::Raised);
        pushButton_5 = new QPushButton(centralwidget);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(334, 340, 241, 100));
        pushButton_5->setStyleSheet(QString::fromUtf8("*{\n"
"\n"
"\n"
"background-color: transparent;\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/ajout.png);\n"
"\n"
"}\n"
"\n"
"*:hover\n"
"{\n"
"\n"
"background-color: transparent;\n"
"\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/ajoutcat.png);\n"
"width: 10px;\n"
"height:1000px;\n"
"}"));
        pushButton_6 = new QPushButton(centralwidget);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(930, 810, 241, 100));
        pushButton_6->setStyleSheet(QString::fromUtf8("*{\n"
"\n"
"\n"
"background-color: transparent;\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/suppbtn.png);\n"
"\n"
"}\n"
"\n"
"*:hover\n"
"{\n"
"\n"
"background-color: transparent;\n"
"\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/suppbtncat.png);\n"
"width: 10px;\n"
"height:1000px;\n"
"}"));
        lineEdit = new QLineEdit(centralwidget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(680, 300, 211, 32));
        lineEdit->setStyleSheet(QString::fromUtf8("*{\n"
"background-color:white; \n"
"border: none; \n"
"border-radius: 10px; \n"
"padding: 0 8px; \n"
"selection-background-color: white; \n"
" font-size: 16px;\n"
"}"));
        pushButton_7 = new QPushButton(centralwidget);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setGeometry(QRect(650, 295, 41, 42));
        pushButton_7->setStyleSheet(QString::fromUtf8("*{\n"
"\n"
"\n"
"background-color: transparent;\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/cherchbtn.png);\n"
"\n"
"}\n"
"\n"
"*:hover\n"
"{\n"
"\n"
"background-color: transparent;\n"
"\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/cherchbtnpr.png);\n"
"\n"
"}"));
        pushButton_8 = new QPushButton(centralwidget);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setGeometry(QRect(1560, 330, 241, 100));
        pushButton_8->setStyleSheet(QString::fromUtf8("*{\n"
"\n"
"\n"
"background-color: transparent;\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/modifbtn.png);\n"
"\n"
"}\n"
"\n"
"*:hover\n"
"{\n"
"\n"
"background-color: transparent;\n"
"\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/modifbtncat.png);\n"
"width: 10px;\n"
"height:1000px;\n"
"}"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(310, 450, 111, 81));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(300, 690, 291, 81));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(310, 560, 111, 81));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(1500, 440, 111, 81));
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(1500, 580, 111, 81));
        label_6 = new QLabel(centralwidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(1500, 710, 221, 81));
        label_7 = new QLabel(centralwidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(920, 930, 111, 81));
        lineEdit_idc = new QLineEdit(centralwidget);
        lineEdit_idc->setObjectName(QString::fromUtf8("lineEdit_idc"));
        lineEdit_idc->setGeometry(QRect(500, 460, 151, 41));
        lineEdit_nomc = new QLineEdit(centralwidget);
        lineEdit_nomc->setObjectName(QString::fromUtf8("lineEdit_nomc"));
        lineEdit_nomc->setGeometry(QRect(500, 580, 151, 41));
        lineEdit_ref = new QLineEdit(centralwidget);
        lineEdit_ref->setObjectName(QString::fromUtf8("lineEdit_ref"));
        lineEdit_ref->setGeometry(QRect(500, 710, 151, 41));
        lineEdit_idc_2 = new QLineEdit(centralwidget);
        lineEdit_idc_2->setObjectName(QString::fromUtf8("lineEdit_idc_2"));
        lineEdit_idc_2->setGeometry(QRect(1030, 950, 151, 41));
        lineEdit_idc_3 = new QLineEdit(centralwidget);
        lineEdit_idc_3->setObjectName(QString::fromUtf8("lineEdit_idc_3"));
        lineEdit_idc_3->setGeometry(QRect(1710, 460, 151, 41));
        lineEdit_nomc_2 = new QLineEdit(centralwidget);
        lineEdit_nomc_2->setObjectName(QString::fromUtf8("lineEdit_nomc_2"));
        lineEdit_nomc_2->setGeometry(QRect(1710, 600, 151, 41));
        lineEdit_ref_2 = new QLineEdit(centralwidget);
        lineEdit_ref_2->setObjectName(QString::fromUtf8("lineEdit_ref_2"));
        lineEdit_ref_2->setGeometry(QRect(1710, 730, 151, 41));
        tableView = new QTableView(centralwidget);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(665, 331, 811, 481));
        pushButton_4 = new QPushButton(centralwidget);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(1380, 300, 93, 28));
        gescat->setCentralWidget(centralwidget);
        pushButton_7->raise();
        des2->raise();
        des1->raise();
        logo->raise();
        pushButton_3->raise();
        pushButton_2->raise();
        backing->raise();
        pushButton_5->raise();
        pushButton_6->raise();
        lineEdit->raise();
        pushButton_8->raise();
        label->raise();
        label_2->raise();
        label_3->raise();
        label_4->raise();
        label_5->raise();
        label_6->raise();
        label_7->raise();
        lineEdit_idc->raise();
        lineEdit_nomc->raise();
        lineEdit_ref->raise();
        lineEdit_idc_2->raise();
        lineEdit_idc_3->raise();
        lineEdit_nomc_2->raise();
        lineEdit_ref_2->raise();
        tableView->raise();
        pushButton_4->raise();
        menubar = new QMenuBar(gescat);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1862, 26));
        gescat->setMenuBar(menubar);
        statusbar = new QStatusBar(gescat);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        gescat->setStatusBar(statusbar);

        retranslateUi(gescat);

        QMetaObject::connectSlotsByName(gescat);
    } // setupUi

    void retranslateUi(QMainWindow *gescat)
    {
        gescat->setWindowTitle(QApplication::translate("gescat", "widget", nullptr));
        acceuilbtn->setText(QString());
        pushButton->setText(QString());
        quitter->setText(QString());
        grandir->setText(QString());
        pushButton_3->setText(QString());
        pushButton_2->setText(QString());
        pushButton_5->setText(QString());
        pushButton_6->setText(QString());
        pushButton_7->setText(QString());
        pushButton_8->setText(QString());
        label->setText(QApplication::translate("gescat", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#ffff7f;\">IDC</span></p></body></html>", nullptr));
        label_2->setText(QApplication::translate("gescat", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#ffff7f;\">REFERENCE</span></p></body></html>", nullptr));
        label_3->setText(QApplication::translate("gescat", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#ffff7f;\">NOM</span></p></body></html>", nullptr));
        label_4->setText(QApplication::translate("gescat", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#ffff7f;\">IDC</span></p></body></html>", nullptr));
        label_5->setText(QApplication::translate("gescat", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#ffff7f;\">NOM</span></p></body></html>", nullptr));
        label_6->setText(QApplication::translate("gescat", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#ffff7f;\">REFERENCE</span></p></body></html>", nullptr));
        label_7->setText(QApplication::translate("gescat", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#ffff7f;\">IDC</span></p></body></html>", nullptr));
        pushButton_4->setText(QApplication::translate("gescat", "PDF", nullptr));
    } // retranslateUi

};

namespace Ui {
    class gescat: public Ui_gescat {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GESCAT_H
