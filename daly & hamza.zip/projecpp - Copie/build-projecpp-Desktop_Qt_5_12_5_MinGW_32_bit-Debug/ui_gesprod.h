/********************************************************************************
** Form generated from reading UI file 'gesprod.ui'
**
** Created by: Qt User Interface Compiler version 5.12.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GESPROD_H
#define UI_GESPROD_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Gesprod
{
public:
    QWidget *centralwidget;
    QFrame *des1;
    QPushButton *acceuilbtn;
    QFrame *logo;
    QFrame *des2;
    QPushButton *pushButton;
    QPushButton *quitter;
    QPushButton *grandir;
    QPushButton *pushButton_3;
    QPushButton *pushButton_2;
    QFrame *backing;
    QFrame *motlvr;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QLineEdit *lineEdit;
    QPushButton *pushButton_7;
    QLabel *label;
    QLineEdit *lineEdit_idp;
    QLabel *label_2;
    QLineEdit *lineEdit_nom;
    QLabel *label_3;
    QLineEdit *lineEdit_quantite;
    QLineEdit *lineEdit_idp_3;
    QLineEdit *lineEdit_nomp_2;
    QLineEdit *lineEdit_quantite_2;
    QLineEdit *lineEdit_idp_2;
    QLabel *label_4;
    QLabel *label_8;
    QLabel *label_5;
    QLabel *label_6;
    QTableView *tableView;
    QPushButton *pushButton_8;
    QLabel *label_7;
    QLabel *label_9;
    QComboBox *comboBox;
    QComboBox *comboBox_2;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Gesprod)
    {
        if (Gesprod->objectName().isEmpty())
            Gesprod->setObjectName(QString::fromUtf8("Gesprod"));
        Gesprod->resize(1876, 1093);
        QSizePolicy sizePolicy(QSizePolicy::Maximum, QSizePolicy::Maximum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(Gesprod->sizePolicy().hasHeightForWidth());
        Gesprod->setSizePolicy(sizePolicy);
        Gesprod->setStyleSheet(QString::fromUtf8("#centralwidget\n"
"{\n"
"background: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/back.png);\n"
"}\n"
"#des1\n"
"{\n"
"background:#fec424;\n"
"\n"
"}\n"
"#des2\n"
"{\n"
"background:#fec424;\n"
"\n"
"}\n"
"#logo\n"
"{\n"
"background: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/rpl.png);\n"
"}\n"
"\n"
"#backing\n"
"{\n"
"background: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/backing.png);\n"
"}\n"
"\n"
"#motlvr\n"
"{\n"
"background: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/motprod.png);\n"
"}"));
        Gesprod->setAnimated(true);
        centralwidget = new QWidget(Gesprod);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        des1 = new QFrame(centralwidget);
        des1->setObjectName(QString::fromUtf8("des1"));
        des1->setGeometry(QRect(-10, 94, 6000, 41));
        des1->setFrameShape(QFrame::StyledPanel);
        des1->setFrameShadow(QFrame::Raised);
        acceuilbtn = new QPushButton(des1);
        acceuilbtn->setObjectName(QString::fromUtf8("acceuilbtn"));
        acceuilbtn->setGeometry(QRect(970, -25, 301, 91));
        acceuilbtn->setStyleSheet(QString::fromUtf8("*{\n"
"width: 10px;\n"
"\n"
"background-color: transparent;\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/title.png);\n"
"background: none;\n"
"border: none;\n"
"background-repeat: none;\n"
"}\n"
"\n"
"*:hover\n"
"{\n"
"width: 10px;\n"
"background-color: transparent;\n"
"\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/titlepr.png);\n"
"background: none;\n"
"border: none;\n"
"background-repeat: none;\n"
"}"));
        logo = new QFrame(centralwidget);
        logo->setObjectName(QString::fromUtf8("logo"));
        logo->setGeometry(QRect(20, -20, 251, 251));
        logo->setFrameShape(QFrame::StyledPanel);
        logo->setFrameShadow(QFrame::Raised);
        des2 = new QFrame(centralwidget);
        des2->setObjectName(QString::fromUtf8("des2"));
        des2->setGeometry(QRect(-10, 120, 301, 1091));
        des2->setStyleSheet(QString::fromUtf8(""));
        des2->setFrameShape(QFrame::StyledPanel);
        des2->setFrameShadow(QFrame::Raised);
        pushButton = new QPushButton(des2);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(20, 130, 261, 51));
        pushButton->setStyleSheet(QString::fromUtf8("*{\n"
"width: 10px;\n"
"\n"
"background-color: transparent;\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/gg.png);\n"
"background: none;\n"
"border: none;\n"
"background-repeat: none;\n"
"}\n"
"\n"
"*:hover\n"
"{\n"
"\n"
"}"));
        quitter = new QPushButton(des2);
        quitter->setObjectName(QString::fromUtf8("quitter"));
        quitter->setGeometry(QRect(120, 830, 51, 41));
        quitter->setStyleSheet(QString::fromUtf8("*{\n"
"width: 10px;\n"
"\n"
"background-color: transparent;\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/exit.png);\n"
"background: none;\n"
"border: none;\n"
"background-repeat: none;\n"
"}\n"
"*:hover\n"
"{\n"
"\n"
"}"));
        grandir = new QPushButton(des2);
        grandir->setObjectName(QString::fromUtf8("grandir"));
        grandir->setGeometry(QRect(120, 760, 51, 41));
        grandir->setStyleSheet(QString::fromUtf8("*{\n"
"width: 10px;\n"
"\n"
"background-color: transparent;\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/agrandir.png);\n"
"background: none;\n"
"border: none;\n"
"background-repeat: none;\n"
"}\n"
"\n"
"*:hover\n"
"{\n"
"width: 10px;\n"
"background-color: transparent;\n"
"\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/exit1.png);\n"
"background: none;\n"
"border: none;\n"
"background-repeat: none;\n"
"}"));
        pushButton_3 = new QPushButton(centralwidget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(485, 150, 121, 51));
        pushButton_3->setStyleSheet(QString::fromUtf8("*{\n"
"width: 10px;\n"
"\n"
"background-color: transparent;\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/btncatc.png);\n"
"background: none;\n"
"border: none;\n"
"background-repeat: none;\n"
"}\n"
"\n"
""));
        pushButton_2 = new QPushButton(centralwidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(330, 150, 161, 51));
        pushButton_2->setStyleSheet(QString::fromUtf8("*{\n"
"width: 10px;\n"
"\n"
"background-color: transparent;\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/btnprodpr.png);\n"
"background: none;\n"
"border: none;\n"
"background-repeat: none;\n"
"}\n"
"\n"
""));
        backing = new QFrame(centralwidget);
        backing->setObjectName(QString::fromUtf8("backing"));
        backing->setGeometry(QRect(290, 210, 2001, 71));
        backing->setFrameShape(QFrame::StyledPanel);
        backing->setFrameShadow(QFrame::Raised);
        motlvr = new QFrame(backing);
        motlvr->setObjectName(QString::fromUtf8("motlvr"));
        motlvr->setGeometry(QRect(-130, -10, 521, 91));
        motlvr->setFrameShape(QFrame::StyledPanel);
        motlvr->setFrameShadow(QFrame::Raised);
        pushButton_4 = new QPushButton(centralwidget);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(330, 300, 241, 100));
        pushButton_4->setStyleSheet(QString::fromUtf8("*{\n"
"\n"
"\n"
"background-color: transparent;\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/ajout.png);\n"
"\n"
"}\n"
"\n"
"*:hover\n"
"{\n"
"\n"
"background-color: transparent;\n"
"\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/ajoutprod.png);\n"
"\n"
"}"));
        pushButton_5 = new QPushButton(centralwidget);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(1610, 320, 241, 100));
        pushButton_5->setStyleSheet(QString::fromUtf8("*{\n"
"\n"
"\n"
"background-color: transparent;\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/modifbtn.png);\n"
"\n"
"}\n"
"\n"
"*:hover\n"
"{\n"
"\n"
"background-color: transparent;\n"
"\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/modifbtnprod.png);\n"
"width: 10px;\n"
"height:1000px;\n"
"}"));
        pushButton_6 = new QPushButton(centralwidget);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(980, 830, 241, 100));
        pushButton_6->setStyleSheet(QString::fromUtf8("*{\n"
"\n"
"\n"
"background-color: transparent;\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/suppbtn.png);\n"
"\n"
"}\n"
"\n"
"*:hover\n"
"{\n"
"\n"
"background-color: transparent;\n"
"\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/suppbtnprod.png);\n"
"width: 10px;\n"
"height:1000px;\n"
"}"));
        lineEdit = new QLineEdit(centralwidget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(680, 300, 211, 32));
        lineEdit->setStyleSheet(QString::fromUtf8("*{\n"
"background-color:white; \n"
"border: none; \n"
"border-radius: 10px; \n"
"padding: 0 8px; \n"
"selection-background-color: white; \n"
" font-size: 16px;\n"
"}"));
        pushButton_7 = new QPushButton(centralwidget);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setGeometry(QRect(650, 295, 41, 42));
        pushButton_7->setStyleSheet(QString::fromUtf8("*{\n"
"\n"
"\n"
"background-color: transparent;\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/cherchbtn.png);\n"
"\n"
"}\n"
"\n"
"*:hover\n"
"{\n"
"\n"
"background-color: transparent;\n"
"\n"
"border-image: url(C:/Users/ASUS/Desktop/projecpp - Copie/Gestion Produit/image/cherchbtnpr.png);\n"
"\n"
"}"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(340, 420, 111, 81));
        lineEdit_idp = new QLineEdit(centralwidget);
        lineEdit_idp->setObjectName(QString::fromUtf8("lineEdit_idp"));
        lineEdit_idp->setGeometry(QRect(460, 440, 151, 41));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(340, 550, 81, 41));
        lineEdit_nom = new QLineEdit(centralwidget);
        lineEdit_nom->setObjectName(QString::fromUtf8("lineEdit_nom"));
        lineEdit_nom->setGeometry(QRect(460, 550, 151, 41));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(290, 670, 161, 41));
        lineEdit_quantite = new QLineEdit(centralwidget);
        lineEdit_quantite->setObjectName(QString::fromUtf8("lineEdit_quantite"));
        lineEdit_quantite->setGeometry(QRect(460, 670, 151, 41));
        lineEdit_idp_3 = new QLineEdit(centralwidget);
        lineEdit_idp_3->setObjectName(QString::fromUtf8("lineEdit_idp_3"));
        lineEdit_idp_3->setGeometry(QRect(1720, 460, 151, 41));
        lineEdit_nomp_2 = new QLineEdit(centralwidget);
        lineEdit_nomp_2->setObjectName(QString::fromUtf8("lineEdit_nomp_2"));
        lineEdit_nomp_2->setGeometry(QRect(1720, 570, 151, 41));
        lineEdit_quantite_2 = new QLineEdit(centralwidget);
        lineEdit_quantite_2->setObjectName(QString::fromUtf8("lineEdit_quantite_2"));
        lineEdit_quantite_2->setGeometry(QRect(1720, 670, 151, 41));
        lineEdit_idp_2 = new QLineEdit(centralwidget);
        lineEdit_idp_2->setObjectName(QString::fromUtf8("lineEdit_idp_2"));
        lineEdit_idp_2->setGeometry(QRect(1020, 960, 151, 41));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(1600, 440, 111, 81));
        label_8 = new QLabel(centralwidget);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(1590, 570, 81, 41));
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(1560, 670, 161, 41));
        label_6 = new QLabel(centralwidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(910, 940, 111, 81));
        tableView = new QTableView(centralwidget);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(630, 330, 711, 421));
        pushButton_8 = new QPushButton(centralwidget);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setGeometry(QRect(1250, 300, 93, 28));
        label_7 = new QLabel(centralwidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(330, 750, 111, 81));
        label_9 = new QLabel(centralwidget);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(1580, 770, 111, 81));
        comboBox = new QComboBox(centralwidget);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(460, 780, 151, 41));
        comboBox_2 = new QComboBox(centralwidget);
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->setObjectName(QString::fromUtf8("comboBox_2"));
        comboBox_2->setGeometry(QRect(1720, 790, 151, 41));
        Gesprod->setCentralWidget(centralwidget);
        pushButton_7->raise();
        des2->raise();
        des1->raise();
        logo->raise();
        pushButton_3->raise();
        pushButton_2->raise();
        backing->raise();
        pushButton_4->raise();
        pushButton_5->raise();
        pushButton_6->raise();
        lineEdit->raise();
        label->raise();
        lineEdit_idp->raise();
        label_2->raise();
        lineEdit_nom->raise();
        label_3->raise();
        lineEdit_quantite->raise();
        lineEdit_idp_3->raise();
        lineEdit_nomp_2->raise();
        lineEdit_quantite_2->raise();
        lineEdit_idp_2->raise();
        label_4->raise();
        label_8->raise();
        label_5->raise();
        label_6->raise();
        tableView->raise();
        pushButton_8->raise();
        label_7->raise();
        label_9->raise();
        comboBox->raise();
        comboBox_2->raise();
        menubar = new QMenuBar(Gesprod);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1876, 26));
        Gesprod->setMenuBar(menubar);
        statusbar = new QStatusBar(Gesprod);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        Gesprod->setStatusBar(statusbar);

        retranslateUi(Gesprod);

        QMetaObject::connectSlotsByName(Gesprod);
    } // setupUi

    void retranslateUi(QMainWindow *Gesprod)
    {
        Gesprod->setWindowTitle(QApplication::translate("Gesprod", "widget", nullptr));
        acceuilbtn->setText(QString());
        pushButton->setText(QString());
        quitter->setText(QString());
        grandir->setText(QString());
        pushButton_3->setText(QString());
        pushButton_2->setText(QString());
        pushButton_4->setText(QString());
        pushButton_5->setText(QString());
        pushButton_6->setText(QString());
        pushButton_7->setText(QString());
        label->setText(QApplication::translate("Gesprod", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#ffff7f;\">IDP</span></p></body></html>", nullptr));
        label_2->setText(QApplication::translate("Gesprod", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#ffff7f;\">NOM</span></p></body></html>", nullptr));
        label_3->setText(QApplication::translate("Gesprod", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#ffff7f;\">QUANTITE</span></p></body></html>", nullptr));
        label_4->setText(QApplication::translate("Gesprod", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#ffff7f;\">IDP</span></p></body></html>", nullptr));
        label_8->setText(QApplication::translate("Gesprod", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#ffff7f;\">NOM</span></p></body></html>", nullptr));
        label_5->setText(QApplication::translate("Gesprod", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#ffff7f;\">QUANTITE</span></p></body></html>", nullptr));
        label_6->setText(QApplication::translate("Gesprod", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#ffff7f;\">IDP</span></p></body></html>", nullptr));
        pushButton_8->setText(QApplication::translate("Gesprod", "PDF", nullptr));
        label_7->setText(QApplication::translate("Gesprod", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#ffff7f;\">TYPE</span></p></body></html>", nullptr));
        label_9->setText(QApplication::translate("Gesprod", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#ffff7f;\">TYPE</span></p></body></html>", nullptr));
        comboBox->setItemText(0, QApplication::translate("Gesprod", "Papier important", nullptr));
        comboBox->setItemText(1, QApplication::translate("Gesprod", "Timbre", nullptr));

        comboBox_2->setItemText(0, QApplication::translate("Gesprod", "Papier important", nullptr));
        comboBox_2->setItemText(1, QApplication::translate("Gesprod", "Timbre", nullptr));

    } // retranslateUi

};

namespace Ui {
    class Gesprod: public Ui_Gesprod {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GESPROD_H
