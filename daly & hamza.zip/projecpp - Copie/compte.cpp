#include "compte.h"
#include <QDebug>
#include "connection.h"

compte::compte()
{
cin="";
type="";
solde="";
}
compte::compte(QString cin,QString type,QString solde)
{
  this->cin=cin;
  this->type=type ;
  this->solde=solde ;
}
QString compte::get_cin(){return  cin;}
QString compte::get_type(){return type;}
QString compte::get_ref(){return ref;}
QString compte::get_solde(){return solde;}

bool compte::ajouter()
{
QSqlQuery query;
query.prepare("INSERT INTO compte (CIN,TYPE,REF,SOLDE ) "
              "VALUES (:cin, :type,:ref,:solde)");
query.bindValue(":cin", cin);
query.bindValue(":type", type);
query.bindValue(":ref", ref);
query.bindValue(":solde", solde);
return    query.exec();
}
bool compte::modifier()
{
    QSqlQuery query;
    query.prepare("UPDATE compte SET type='"+type+"',solde='"+solde+"' where cin='"+cin+"';");
    query.bindValue(":cin",cin);
    query.bindValue(":type", type);
    query.bindValue(":solde", solde);
    return    query.exec();
}



QSqlQueryModel * compte::afficher()
{
    QSqlQueryModel * model= new QSqlQueryModel();
model->setQuery("select * from compte");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("CIN"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("Type du compte"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("RIB")) ;
model->setHeaderData(3, Qt::Horizontal, QObject::tr("Solde")) ;
    return model;
}


QSqlQueryModel * compte::afficherarchives()
{
    QSqlQueryModel * model= new QSqlQueryModel();
model->setQuery("select cin,nom,prenom from archives");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("CIN"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom "));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("Prénom"));
    return model;
}


QSqlQueryModel * compte::tri()
{
    QSqlQueryModel * model= new QSqlQueryModel();
    model->setQuery("select * from compte order by cin asc;");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("CIN"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Type du compte"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("RIB")) ;
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("Solde")) ;
        return model;
}

bool compte::supprimer(QString ciin)
{
QSqlQuery query;
query.prepare("Delete from compte where CIN = :cin ");
query.bindValue(":cin", ciin);
return    query.exec();
}
bool compte::rechercher(QString ciin)
{
    QSqlQuery query;

query.prepare("SELECT cin FROM compte WHERE cin='"+ciin+"' ");
query.bindValue(":cin", ciin);
return    query.exec();
}

