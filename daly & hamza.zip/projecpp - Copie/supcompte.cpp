#include "supcompte.h"
#include "ajoutcompte.h"
#include "ui_ajoutcompte.h"
#include "compte.h"
#include "gescompte.h"
#include "ui_gescompte.h"
#include "ui_supcompte.h"

#include <QMessageBox>
supcompte::supcompte(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::supcompte)
{
    ui->setupUi(this);
}

supcompte::~supcompte()
{
    delete ui;
}

/*void supcompte::on_pb_supprimer_clicked()
{
    ajoutcompte addcompte;
    addcompte.setModal(true);
    addcompte.exec();
int cin = ui->lineEdit_id_2->text().toInt();
bool test=tmpcompte.supprimer(cin);
if(test)
{
    QMessageBox::information(nullptr, QObject::tr("Supprimer un compte"),
                QObject::tr("Compte supprimé.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);

}
else
    QMessageBox::critical(nullptr, QObject::tr("Supprimer un Compte"),
                QObject::tr("Erreur !.\n"
                            "Click Cancel to exit."), QMessageBox::Cancel);


}*/

void supcompte::on_pushButton_clicked()
{
    int cin = ui->lineEdit_id_2->text().toInt();
    bool test=tmpcompte.supprimer(cin);
    if(test)
    {
        // ui->tableView->setModel(tmpcompte.afficher());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer un compte"),
                    QObject::tr("Compte supprimé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer un Compte"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    this->close();
    this->deleteLater();
}
