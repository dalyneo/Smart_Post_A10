#ifndef Gescompte_H
#define Gescompte_H
#include "compte.h"
#include <QMainWindow>
#include <QTimer>
#include <QTextToSpeech>
#include <QMediaPlayer>
QT_BEGIN_NAMESPACE
namespace Ui {
class Gescompte;
}
QT_END_NAMESPACE
class Gescompte : public QMainWindow
{
    Q_OBJECT

public:
    explicit Gescompte(QWidget *parent = nullptr);
    ~Gescompte();

private slots:

    void closeWin();
    void on_acceuilbtn_clicked();

    void on_quitter_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

   // void on_pushButton_7_clicked();

    //void on_lineEdit_textEdited(const QString &arg1);


    void on_pushButton_6_clicked();


    void on_imprimer_clicked();

    void on_pushButton_8_clicked();

    void on_pushButton_7_clicked();

    void on_act_clicked();




    void on_tableView_activated(const QModelIndex &index);

    void on_archives_clicked();




     void on_pushButton_2_clicked();

     void on_quitter_2_clicked();


private:
QMediaPlayer * erreur = new QMediaPlayer ;
    compte tmpcompte;
     QTimer *delay;
    Ui::Gescompte *ui;
    QTextToSpeech *speech;
    QStringList allTextList;
};

#endif // Gescompte_H
