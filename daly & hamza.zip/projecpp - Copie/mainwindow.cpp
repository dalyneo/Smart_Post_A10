#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "gescompte.h"
#include "ui_gescompte.h"
#include "compte.h"
#include "ui_gescarte.h"
#include "gescarte.h"
#include <QMessageBox>
#include <QWidget>
#include <vector>
#include <QString>
#include <iostream>
#include <QLineEdit>
#include <QMediaPlayer>
#include "Gestion_Produit/produit.h"
#include "Gestion_Produit/gesprod.h"
#include "ui_gesprod.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //ui->tabcompte->setModel(tmpcompte.afficher());

   /* stop->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/music.mp3")) ;
    stop->setVolume(100) ;
    stop->play() ; */

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::closeWin()
{
 this->close();

}
void MainWindow::on_pushButton_clicked()
{

     ges = new Gescompte();
      ges->showFullScreen();
      delay = new QTimer(this);
     connect(delay,SIGNAL(timeout()),this,SLOT(closeWin()));
     delay->start(500);





}



void MainWindow::on_pushButton_4_clicked()
{

    gescarte *ges;
    ges = new gescarte();
     ges->showFullScreen();
     delay = new QTimer(this);
    connect(delay,SIGNAL(timeout()),this,SLOT(closeWin()));
    delay->start(500);
}

void MainWindow::on_pushButton_2_clicked()
{
    this->close();
}


void MainWindow::on_quitter_2_clicked()
{
    MainWindow *main;
    main = new MainWindow();
    main->show();
    delay = new QTimer(this);
   connect(delay,SIGNAL(timeout()),this,SLOT(closeWin()));
   delay->start(500);
}

void MainWindow::on_quitter_3_clicked()
{
  stop->pause() ;
}


void MainWindow::on_pushButton_5_clicked()
{
    QString help=ui->help->text();
    if(help=="comment ajouter ?")
    {
        stop->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/helpajoute.mp3")) ;
            stop->setVolume(100) ;
            stop->play() ;
    }
    else if (help=="comment modifier un champ ?")
    {
        stop->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/helpmodifier.mp3")) ;
            stop->setVolume(100) ;
            stop->play() ;
    }
    else if (help=="comment supprimer un champ ?")
    {
        stop->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/helpsupprimer.mp3")) ;
            stop->setVolume(100) ;
            stop->play() ;
    }
    else
    {
        stop->setMedia(QUrl("C:/Users/ASUS/Desktop/projecpp - Copie/sounds/helpadmin.mp3")) ;
            stop->setVolume(100) ;
            stop->play() ;
    }
}

void MainWindow::on_pushButton_6_clicked()
{
    gess = new Gesprod();
     gess->showFullScreen();
     delay = new QTimer(this);
    connect(delay,SIGNAL(timeout()),this,SLOT(closeWin()));
    delay->start(500);
}
