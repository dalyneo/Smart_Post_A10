#ifndef CATEGORIE_H
#define CATEGORIE_H


#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
class categorie
{
public:
    categorie();
    categorie(int,QString,QString);
    int get_idc();
    QString get_nomc();
    QString get_reference();
    bool ajouter();
    bool modifier();
    QSqlQueryModel * afficher();
    bool supprimer(int);
    QSqlQueryModel * tri() ;
private:
    int idc;
    QString nomc,reference;

};

#endif // CATEGORIE_H
