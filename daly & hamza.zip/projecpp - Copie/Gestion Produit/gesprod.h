#ifndef GESPROD_H
#define GESPROD_H

#include <QMainWindow>
#include <QTimer>
#include "produit.h"
#include <QComboBox>
QT_BEGIN_NAMESPACE
namespace Ui {
class Gesprod;
}
QT_END_NAMESPACE
class Gesprod : public QMainWindow
{
    Q_OBJECT

public:
    explicit Gesprod(QWidget *parent = nullptr);
    ~Gesprod();

private slots:

    void closeWin();
    void on_acceuilbtn_clicked();

    void on_quitter_clicked();

    void on_pushButton_3_clicked();
void on_pushButton_7_clicked();
void on_pushButton_8_clicked();
    void on_pushButton_4_clicked();
void fillUpComboBox();
    void on_pushButton_5_clicked();
void on_pushButton_6_clicked();
void on_tableView_activated(const QModelIndex &index);
void on_grandir_clicked();

private:
QComboBox *m_cbb;
     QTimer *delay;
    Ui::Gesprod *ui;
    produit tmpproduit;
};

#endif // GESLIV_H
