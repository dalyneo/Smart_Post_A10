#include "gescat.h"
#include "mainwindow.h"
#include "ui_gescat.h"

#include <QMessageBox>
#include "categorie.h"
#include <QtPrintSupport/QPrinter>
#include <QPdfWriter>
#include <QFileDialog>
#include <QTextDocument>


gescat::gescat(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::gescat)
{
    ui->setupUi(this);
    ui->tableView->setModel(tmpcat.afficher());
}

gescat::~gescat()
{
    delete ui;
}
void gescat::closeWin()
{
 this->close();
    this->deleteLater();
}
void gescat::on_pushButton_2_clicked()
{
    Gesprod *ges;
    ges = new Gesprod();
     ges->showFullScreen();
     delay = new QTimer(this);
    connect(delay,SIGNAL(timeout()),this,SLOT(closeWin()));
    delay->start(500);
}



void gescat::on_acceuilbtn_clicked()
{
    MainWindow *main;
    main = new MainWindow();
    main->showFullScreen();
    delay = new QTimer(this);
   connect(delay,SIGNAL(timeout()),this,SLOT(closeWin()));
   delay->start(500);

}

void gescat::on_quitter_clicked()
{

           this->close();
  this->deleteLater();

}

void gescat::on_pushButton_5_clicked()
{ int idc = ui->lineEdit_idc->text().toInt();
    QString nomc= ui->lineEdit_nomc->text();
    QString reference= ui->lineEdit_ref->text();
    categorie c(idc,nomc,reference);
  bool test=c.ajouter();

  if(test)
{
QMessageBox::information(nullptr, QObject::tr("Ajouter un produit"),
                  QObject::tr("produit ajouté.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);
}
  else
      QMessageBox::critical(nullptr, QObject::tr("Ajouter un produit"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

  ui->tableView->setModel(tmpcat.afficher());
  /*ajoutlivreur addlivs;
    addlivs.setModal(true);
    addlivs.exec();*/

}
void gescat::on_pushButton_6_clicked()
{
     int idc = ui->lineEdit_idc_2->text().toInt();
     bool test=tmpcat.supprimer(idc);
     if (test)
     {ui->tableView->setModel(tmpcat.afficher());
         QMessageBox::information(nullptr, QObject::tr("supprimer une categorie"),
                           QObject::tr(" categorie supprimer.\n"
                                       "Click Cancel to exit."), QMessageBox::Cancel);
         }
           else
               QMessageBox::critical(nullptr, QObject::tr("Supprimer une categorie"),
                           QObject::tr("Erreur !.\n"
                                       "Click Cancel to exit."), QMessageBox::Cancel);


ui->tableView->setModel(tmpcat.afficher());

}
void gescat::on_pushButton_8_clicked()
{
    int idc = ui->lineEdit_idc_3->text().toInt();
    QString nomc= ui->lineEdit_nomc_2->text();
    QString reference= ui->lineEdit_ref_2->text();
    categorie c(idc,nomc,reference);
  bool test=c.modifier();
  if(test)
{
QMessageBox::information(nullptr, QObject::tr("modifier une catégorie"),
                  QObject::tr("catégorie modifié.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);
}
  else
      QMessageBox::critical(nullptr, QObject::tr("modifier une catégorie"),
                  QObject::tr("Erreur !.\n" "Click Cancel to exit."), QMessageBox::Cancel);
  ui->tableView->setModel(tmpcat.afficher());
    /*modifierlivreur modlivs;
    modlivs.setModal(true);
    modlivs.exec();*/
}
void gescat::on_pushButton_7_clicked()
{


    int iidc = ui->lineEdit->text().toInt();
        QSqlQueryModel * model= new QSqlQueryModel();
        QSqlQuery* qry=new QSqlQuery();
        qry->prepare("SELECT * from CATEGORIE where idc like concat (:iidc,'%')");
        qry->bindValue(":iidc",iidc);
        qry->exec();
        model->setQuery(*qry);
        ui->tableView->setModel(model) ;
}
void gescat::on_pushButton_4_clicked()
{

    QString str;
        str.append("<html><head></head><body><center>"+QString("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;;<font size=""10"" color =""red""> GESTION DES CATEGORIES </font><br /> <br /> "));
        str.append("<table border=1><tr>");
        str.append("<td>"+QString("  ")+"&nbsp;&nbsp;<font color =""blue""  size=""10"">IDC</font>&nbsp;&nbsp;"+"</td>");
        str.append("<td>"+QString("&nbsp;&nbsp;<font color =""blue""  size=""10"">Nom </font>&nbsp;&nbsp;")+"</td>");
        str.append("<td>"+QString("&nbsp;&nbsp;<font color =""blue""  size=""10"">Référence</font>&nbsp;&nbsp;")+"</td>");


        QSqlQuery * query=new QSqlQuery();
        query->exec("SELECT idc,nomc,reference FROM CATEGORIE");
        while(query->next())
        {
            str.append("<tr><td>");
            str.append("&nbsp;&nbsp;<font color =""green"" size= ""10"">"+query->value(0).toString()+"&nbsp;&nbsp;");
            str.append("</td><td>");
            str.append("&nbsp;&nbsp;<font color =""green""  size=""10"">"+query->value(1).toString()+"&nbsp;&nbsp;");
            str.append("</td><td>");
            str.append("&nbsp;&nbsp;<font color =""green"" size=""10"">"+query->value(2).toString()+"&nbsp;&nbsp;");
             str.append("</td><td>");
            str.append("&nbsp;&nbsp;<font color =""green"" size= ""10"">"+query->value(3).toString()+"&nbsp;&nbsp;");
            str.append("</td><td>");
            str.append("&nbsp;&nbsp;<font color =""green""  size=""10"">"+query->value(4).toString()+"&nbsp;&nbsp;");
            str.append("</td><td>");
            str.append("&nbsp;&nbsp;<font color =""green"" size=""10"">"+query->value(5).toString()+"&nbsp;&nbsp;");
            str.append("</td></tr>");

    }

        str.append("</table></center><body></html>");

        QPrinter printer;
        printer.setOrientation(QPrinter::Portrait);
        printer.setOutputFormat(QPrinter::PdfFormat);
        printer.setPaperSize(QPrinter::A4);

        QString path= QFileDialog::getSaveFileName(NULL,"imprimer","gestion des catégories","PDF(*.pdf");
         if(path.isEmpty()) return;
         printer.setOutputFileName(path);
         QTextDocument doc;
         doc.setHtml(str);
         doc.print(&printer);



}
void gescat::on_tableView_activated(const QModelIndex &index)
{
    QString val = ui->tableView->model()->data(index).toString() ;
       QSqlQuery qry;
       qry.prepare(" SELECT * from CATEGORIE where idc = '"+val+"'");
       if (qry.exec())
       {
           while (qry.next()) {
               ui->lineEdit_idc->setText(qry.value(0).toString()) ;
               ui->lineEdit_nomc->setText(qry.value(1).toString()) ;
               ui->lineEdit_ref->setText(qry.value(2).toString()) ;



              ui->lineEdit_idc_2->setText(qry.value(0).toString()) ;

                  ui->lineEdit_idc_3->setText(qry.value(0).toString()) ;
                  ui->lineEdit_nomc_2->setText(qry.value(1).toString()) ;
                  ui->lineEdit_ref_2->setText(qry.value(2).toString()) ;

              }
              ui->tableView->setModel(tmpcat.afficher());
      }
}





void gescat::on_grandir_clicked()
{
    gescat *ges;
        ges = new gescat();
         ges->show();
         delay = new QTimer(this);
        connect(delay,SIGNAL(timeout()),this,SLOT(closeWin()));
        delay->start(500);
}
