#ifndef PRODUIT_H
#define PRODUIT_H


#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
class produit
{
public:
    produit();
    produit(int,QString,QString,QString);
    int get_idp();
    QString get_nomp();
    QString get_quantite();
    QString get_type();
    bool ajouter();
    bool modifier();
    QSqlQueryModel * afficher();
    bool supprimer(int);
    QSqlQueryModel * tri() ;
private:
    int idp;
    QString nomp,quantite,type;

};

#endif // PRODUIT_H
