#include "categorie.h"
#include "connection.h"
categorie::categorie()
{
idc=0;
nomc="";
reference="";
}
categorie::categorie(int idc,QString nomc,QString reference)
{
  this->idc=idc;
  this->nomc=nomc;
  this->reference=reference;
}
int categorie::get_idc(){return  idc;}
QString categorie::get_nomc(){return  nomc;}
QString categorie::get_reference(){return reference;}

bool categorie::ajouter()
{
    QSqlQuery query;
    QString res= QString::number(idc);
    query.prepare("INSERT INTO CATEGORIE (IDC, NOMC, REFERENCE) "
                        "VALUES (:idc, :nomc, :reference)");
    query.bindValue(":idc", res);
    query.bindValue(":nomc", nomc);
    query.bindValue(":reference", reference);
    return    query.exec();
}

bool categorie::modifier()
{
    QSqlQuery query;
    QString res= QString::number(idc);
    query.prepare("UPDATE CATEGORIE SET nomc='"+nomc+"',reference='"+reference+"' where idc='"+res+"'  ;");
    query.bindValue(":idc",idc);
    query.bindValue(":nomc", nomc);
    query.bindValue(":reference", reference);
    return    query.exec();
}

QSqlQueryModel * categorie::afficher()
{QSqlQueryModel * model= new QSqlQueryModel();
model->setQuery("select * from CATEGORIE order by idc asc");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("IDC"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("NOMC "));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("REFERENCE"));
    return model;
}


bool categorie::supprimer(int iidc)
{
QSqlQuery query;
QString res= QString::number(iidc);
query.prepare("Delete from CATEGORIE where IDC = :idc ");
query.bindValue(":idc", res);
return    query.exec();
}

QSqlQueryModel * categorie::tri()
{
    QSqlQueryModel * model= new QSqlQueryModel();
    model->setQuery("select * from CATEGORIE order by idc asc;");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("IDC"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("NOMC "));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("REFERENCE"));
        return model;
}
