#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "gesprod.h"
#include "ui_gesprod.h"
#include <QMessageBox>
#include "produit.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

   /* QPixmap back("C:/Users/RH/Desktop/projecpp/image/back.png");
    ui->background->setPixmap(back);*/
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::closeWin()
{
 this->close();

}
void MainWindow::on_pushButton_clicked()
{

 /*Gestliv ges;
 ges.setModal(true);
 ges.exec();*/
     ges = new Gesprod();
      ges->showFullScreen();
      delay = new QTimer(this);
     connect(delay,SIGNAL(timeout()),this,SLOT(closeWin()));
     delay->start(500);





}

void MainWindow::on_pushButton_2_clicked()
{

   this->close();

}
