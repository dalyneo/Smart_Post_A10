#include "produit.h"
#include "connection.h"
produit::produit()
{
idp=0;
nomp="";
quantite="";
type="";
}
produit::produit(int idp,QString nomp,QString quantite,QString type)
{
  this->idp=idp;
  this->nomp=nomp;
  this->quantite=quantite;
    this->type=type;
}
int produit::get_idp(){return  idp;}
QString produit::get_nomp(){return  nomp;}
QString produit::get_quantite(){return quantite;}
QString produit::get_type(){return type;}

bool produit::ajouter()
{
    QSqlQuery query;
    QString res= QString::number(idp);
    query.prepare("INSERT INTO PRODUIT (IDP, NOMP, QUANTITE, TYPE) "
                        "VALUES (:idp, :nomp, :quantite, :type)");
    query.bindValue(":idp", res);
    query.bindValue(":nomp", nomp);
    query.bindValue(":quantite", quantite);
    query.bindValue(":type", type);
    return    query.exec();
}

bool produit::modifier()

{
    QSqlQuery query;
    QString res= QString::number(idp);
    query.prepare("UPDATE PRODUIT SET nomp='"+nomp+"',quantite='"+quantite+"',type='"+type+"' where idp='"+res+"'  ;");
    query.bindValue(":idp",idp);
    query.bindValue(":nomp", nomp);
    query.bindValue(":quantite", quantite);
    query.bindValue(":type", type);
    return    query.exec();
}

QSqlQueryModel * produit::afficher()
{QSqlQueryModel * model= new QSqlQueryModel();
model->setQuery("select * from PRODUIT order by idp asc");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("IDP"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("NOMP "));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("QUANTITE"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("TYPE"));
    return model;
}


bool produit::supprimer(int iidp)
{
QSqlQuery query;
QString res= QString::number(iidp);
query.prepare("Delete from PRODUIT where IDP = :idp ");
query.bindValue(":idp", res);
return    query.exec();
}

QSqlQueryModel * produit::tri()
{
    QSqlQueryModel * model= new QSqlQueryModel();
    model->setQuery("select * from PRODUIT order by idp asc;");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("IDP"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("NOMP "));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("QUANTITE"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("TYPE"));
        return model;
}

