#ifndef PERMISSIONEXIT_H
#define PERMISSIONEXIT_H

#include <QWidget>

namespace Ui {
class permissionexit;
}

class permissionexit : public QWidget
{
    Q_OBJECT

public:
    explicit permissionexit(QWidget *parent = nullptr);
    ~permissionexit();

private:
    Ui::permissionexit *ui;
};

#endif // PERMISSIONEXIT_H
