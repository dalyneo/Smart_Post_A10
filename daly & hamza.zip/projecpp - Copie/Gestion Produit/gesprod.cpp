#include "gesprod.h"
#include "ui_gesprod.h"
#include "mainwindow.h"
#include "gescat.h"
#include "produit.h"
#include <QMessageBox>
#include <QtPrintSupport/QPrinter>
#include <QPdfWriter>
#include <QFileDialog>
#include <QTextDocument>
#include <QComboBox>
Gesprod::Gesprod(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Gesprod)
{
    ui->setupUi(this);
    //ui->tableView->setModel(model);

    m_cbb = new QComboBox(this);
       m_cbb->move(60, 50);

       QObject::connect(ui->comboBox, &QComboBox::currentTextChanged, this, &Gesprod::parent);
ui->tableView->setModel(tmpproduit.afficher());
}

Gesprod::~Gesprod()
{
    delete ui;
}

void Gesprod::closeWin()
{
 this->close();
    this->deleteLater();
}

void Gesprod::on_acceuilbtn_clicked()
{
    MainWindow *main;
    main = new MainWindow();
    main->showFullScreen();
    delay = new QTimer(this);
   connect(delay,SIGNAL(timeout()),this,SLOT(closeWin()));
   delay->start(500);

}




void Gesprod::on_pushButton_3_clicked()
{
    gescat *ges;
    ges = new gescat();
     ges->showFullScreen();
     delay = new QTimer(this);
    connect(delay,SIGNAL(timeout()),this,SLOT(closeWin()));
    delay->start(500);
}

void Gesprod::on_pushButton_4_clicked()
{
        int idp = ui->lineEdit_idp->text().toInt();
        QString nomp= ui->lineEdit_nom->text();
        QString quantite= ui->lineEdit_quantite->text();
QString type=ui->comboBox->currentText();
        produit p(idp,nomp,quantite,type);
      bool test=p.ajouter();
      if(test)
    {
    QMessageBox::information(nullptr, QObject::tr("Ajouter un produit"),
                      QObject::tr("produit ajouté.\n"
                                  "Click Cancel to exit."), QMessageBox::Cancel);
    }
      else
          QMessageBox::critical(nullptr, QObject::tr("Ajouter un produit"),
                      QObject::tr("Erreur !.\n"
                                  "Click Cancel to exit."), QMessageBox::Cancel);
ui->tableView->setModel(tmpproduit.afficher());
}

void Gesprod::on_pushButton_5_clicked()
{int idp = ui->lineEdit_idp_3->text().toInt();
    QString nomp= ui->lineEdit_nomp_2->text();
    QString quantite= ui->lineEdit_quantite_2->text();
    QString type=ui->comboBox_2->currentText();
    produit p(idp,nomp,quantite,type);
  bool test=p.modifier();

  if(test)
{ui->tableView->setModel(tmpproduit.afficher());
QMessageBox::information(nullptr, QObject::tr("modifier un produit"),
                  QObject::tr("produit modifié.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);
}
  else
      QMessageBox::critical(nullptr, QObject::tr("modifier un produit"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

  ui->tableView->setModel(tmpproduit.afficher());
    /*modifierlivraison modlivs;
    modlivs.setModal(true);
    modlivs.exec();*/
}
void Gesprod::on_pushButton_6_clicked()
{
     int idp = ui->lineEdit_idp_2->text().toInt();
     bool test=tmpproduit.supprimer(idp);
     if (test)
     {ui->tableView->setModel(tmpproduit.afficher());
         QMessageBox::information(nullptr, QObject::tr("supprimer un produit"),
                           QObject::tr("produit supprimé.\n"
                                       "Click Cancel to exit."), QMessageBox::Cancel);
         }
           else
               QMessageBox::critical(nullptr, QObject::tr("Supprimer un produit"),
                           QObject::tr("Erreur !.\n"
                                       "Click Cancel to exit."), QMessageBox::Cancel);

ui->tableView->setModel(tmpproduit.afficher());


}
void Gesprod::on_pushButton_7_clicked()
{
    int iidp = ui->lineEdit->text().toInt();
        QSqlQueryModel * model= new QSqlQueryModel();
        QSqlQuery* qry=new QSqlQuery();
        qry->prepare("SELECT * from PRODUIT where idp like concat (:iidp,'%')");
        qry->bindValue(":iidp",iidp);
        qry->exec();
        model->setQuery(*qry);
        ui->tableView->setModel(model) ;



}

void Gesprod::on_pushButton_8_clicked()
{
    QString str;
        str.append("<html><head></head><body><center>"+QString("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;;<font size=""10"" color =""red""> GESTION DES PRODUITS </font><br /> <br /> "));
        str.append("<table border=1><tr>");
        str.append("<td>"+QString("  ")+"&nbsp;&nbsp;<font color =""blue""  size=""10"">IDP</font>&nbsp;&nbsp;"+"</td>");
        str.append("<td>"+QString("&nbsp;&nbsp;<font color =""blue""  size=""10"">Nom </font>&nbsp;&nbsp;")+"</td>");
        str.append("<td>"+QString("&nbsp;&nbsp;<font color =""blue""  size=""10"">Quantité</font>&nbsp;&nbsp;")+"</td>");


        QSqlQuery * query=new QSqlQuery();
        query->exec("SELECT idp,nomp,quantite FROM PRODUIT");
        while(query->next())
        {
            str.append("<tr><td>");
            str.append("&nbsp;&nbsp;<font color =""green"" size= ""10"">"+query->value(0).toString()+"&nbsp;&nbsp;");
            str.append("</td><td>");
            str.append("&nbsp;&nbsp;<font color =""green""  size=""10"">"+query->value(1).toString()+"&nbsp;&nbsp;");
            str.append("</td><td>");
            str.append("&nbsp;&nbsp;<font color =""green"" size=""10"">"+query->value(2).toString()+"&nbsp;&nbsp;");
             str.append("</td><td>");
            str.append("&nbsp;&nbsp;<font color =""green"" size= ""10"">"+query->value(3).toString()+"&nbsp;&nbsp;");
            str.append("</td><td>");
            str.append("&nbsp;&nbsp;<font color =""green""  size=""10"">"+query->value(4).toString()+"&nbsp;&nbsp;");
            str.append("</td><td>");
            str.append("&nbsp;&nbsp;<font color =""green"" size=""10"">"+query->value(5).toString()+"&nbsp;&nbsp;");
            str.append("</td></tr>");

    }

        str.append("</table></center><body></html>");

        QPrinter printer;
        printer.setOrientation(QPrinter::Portrait);
        printer.setOutputFormat(QPrinter::PdfFormat);
        printer.setPaperSize(QPrinter::A4);

        QString path= QFileDialog::getSaveFileName(NULL,"imprimer","gestion des produits","PDF(*.pdf");
         if(path.isEmpty()) return;
         printer.setOutputFileName(path);
         QTextDocument doc;
         doc.setHtml(str);
         doc.print(&printer);





}

void Gesprod::on_tableView_activated(const QModelIndex &index)
{
    QString val = ui->tableView->model()->data(index).toString() ;
       QSqlQuery qry;
       qry.prepare(" SELECT * from PRODUIT where idp = '"+val+"'");
       if (qry.exec())
       {
           while (qry.next()) {
             ui->lineEdit_idp->setText(qry.value(0).toString()) ;
             ui->lineEdit_nom->setText(qry.value(1).toString()) ;
             ui->lineEdit_quantite->setText(qry.value(2).toString()) ;
             ui->comboBox->setCurrentText(qry.value(3).toString());
             ui->lineEdit_idp_3->setText(qry.value(0).toString()) ;
             ui->lineEdit_nomp_2->setText(qry.value(1).toString()) ;
             ui->lineEdit_quantite_2->setText(qry.value(2).toString()) ;
             ui->comboBox_2->setCurrentText(qry.value(3).toString());
             ui->lineEdit_idp_2->setText(qry.value(0).toString()) ;

           }
       }


}
void Gesprod::fillUpComboBox()
{
    QStringList list;
    list << "Papier important" << "Timbre" ;

    m_cbb->addItems(list);
}


void Gesprod::on_quitter_clicked()
{
    this->close();

}

void Gesprod::on_grandir_clicked()
{
    Gesprod *ges;
        ges = new Gesprod();
         ges->show();
         delay = new QTimer(this);
        connect(delay,SIGNAL(timeout()),this,SLOT(closeWin()));
        delay->start(500);
}
