#include "permissionexit.h"
#include "ui_permissionexit.h"

permissionexit::permissionexit(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::permissionexit)
{
    ui->setupUi(this);
}

permissionexit::~permissionexit()
{
    delete ui;
}
