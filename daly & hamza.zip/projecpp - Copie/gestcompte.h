#ifndef GESTLIV_H
#define GESTLIV_H

#include <QDialog>

namespace Ui {
class Gestliv;
}

class Gestliv : public QDialog
{
    Q_OBJECT

public:
    explicit Gestliv(QWidget *parent = nullptr);
    ~Gestliv();

private:
    Ui::Gestliv *ui;
};

#endif // GESTLIV_H
