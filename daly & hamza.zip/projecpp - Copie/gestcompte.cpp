#include "gestliv.h"
#include "ui_gestliv.h"

Gestliv::Gestliv(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Gestliv)
{
    ui->setupUi(this);
}

Gestliv::~Gestliv()
{
    delete ui;
}
