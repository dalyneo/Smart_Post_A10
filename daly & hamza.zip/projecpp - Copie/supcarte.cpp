#include "carte.h"
#include "supcarte.h"
#include "ui_gescartel.h"
#include "ui_supcarte.h"
#include <QMessageBox>
supcarte::supcarte(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::supcarte)
{
    ui->setupUi(this);
}

supcarte::~supcarte()
{
    delete ui;
}
void supcarte::on_pushButton_clicked()
{
    int cin = ui->lineEdit_id_2->text().toInt();
    bool test=tmpcarte.supprimer(cin);
    if(test)
    {
        // ui->tableView->setModel(tmpcompte.afficher());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer une carte"),
                    QObject::tr("carte supprimé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer une carte"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    this->close();
    this->deleteLater();
}
