#ifndef gescarte_H
#define gescarte_H
#include "carte.h"
#include <QMainWindow>
#include <QTimer>
#include <QMediaPlayer>
/*#include "TTS.hpp"
#include <memory>
#include <thread>
#include <QTextEdit>
*/
namespace Ui {
class gescarte;
}

class gescarte : public QMainWindow
{
    Q_OBJECT

public:
    explicit gescarte(QWidget *parent = nullptr);
    ~gescarte();

private slots:
   // void sendMail();
    void on_pushButton_2_clicked();
    void closeWin();
     void on_quitter_clicked();
    void on_acceuilbtn_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_8_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_7_clicked();

    void on_send_clicked();

    void on_pushButton_9_clicked();

    void on_tableView_activated(const QModelIndex &index);

    void on_historique_clicked();


    void on_pushButton_clicked();

    void on_quitter_2_clicked();

private:
    QMediaPlayer * erreur = new QMediaPlayer ;
    carte tmpcarte;
    carteh tmpcarteh ;
    QTimer *delay;

    Ui::gescarte *ui;
};

#endif // gescarte_H
