#ifndef SUPCARTE_H
#define SUPCARTE_H
#include "carte.h"
#include "ui_supcarte.h"
#include <QDialog>
#include <QMainWindow>
#include <QTimer>
namespace Ui {
class supcarte;
}

class supcarte : public QDialog
{
    Q_OBJECT

public:
    explicit supcarte(QWidget *parent = nullptr);
    ~supcarte();

private slots:
void on_pushButton_clicked() ;

private:
    Ui::supcarte *ui;
     carte tmpcarte;
};

#endif // SUPCARTE_H
