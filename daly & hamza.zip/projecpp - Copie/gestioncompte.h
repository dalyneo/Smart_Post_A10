#ifndef GESTIONLIVRAISON_H
#define GESTIONLIVRAISON_H

#include <QMainWindow>

namespace Ui {
class gestionlivraison;
}

class gestionlivraison : public QMainWindow
{
    Q_OBJECT

public:
    explicit gestionlivraison(QWidget *parent = nullptr);
    ~gestionlivraison();

private:
    Ui::gestionlivraison *ui;
};

#endif // GESTIONLIVRAISON_H
